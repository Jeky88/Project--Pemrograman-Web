// Profile JavaScript
let currentUser = null;
let userPosts = [];
let likedPosts = [];
let activityChart = null;

// DOM Elements
const editProfileModal = new bootstrap.Modal(document.getElementById('editProfileModal'));

// Initialize Profile Page
document.addEventListener('DOMContentLoaded', function() {
    // Check authentication
    auth.onAuthStateChanged((user) => {
        if (user) {
            currentUser = user;
            initializeProfile();
        } else {
            // Redirect to welcome page if not authenticated
            window.location.href = 'welcome.html';
        }
    });
});

// Initialize Profile Functions
function initializeProfile() {
    loadUserProfile();
    loadUserPosts();
    loadLikedPosts();
    loadUserStatistics();
    setupEventListeners();
}

// Setup Event Listeners
function setupEventListeners() {
    // Edit Profile Form
    document.getElementById('editProfileForm').addEventListener('submit', handleEditProfile);
    
    // Tab changes
    document.querySelectorAll('[data-bs-toggle="tab"]').forEach(tab => {
        tab.addEventListener('shown.bs.tab', function(event) {
            const target = event.target.getAttribute('data-bs-target');
            if (target === '#stats') {
                updateActivityChart();
            }
        });
    });
}

// Load User Profile
function loadUserProfile() {
    const userName = currentUser.displayName || currentUser.email;
    const userEmail = currentUser.email;
    
    // Update navigation
    document.getElementById('userName').textContent = userName;
    
    // Update profile header
    document.getElementById('profileUserName').textContent = userName;
    document.getElementById('profileUserEmail').textContent = userEmail;
    
    // Load user data from database
    database.ref(`users/${currentUser.uid}`).once('value', (snapshot) => {
        const userData = snapshot.val();
        if (userData) {
            document.getElementById('profileUserBio').textContent = userData.bio || 'Pecinta anime sejati yang suka berbagi review';
            document.getElementById('profilePostCount').textContent = userData.postCount || 0;
            document.getElementById('profileLikeCount').textContent = userData.likeCount || 0;
            document.getElementById('profileCommentCount').textContent = userData.commentCount || 0;
            
            // Calculate days active
            const joinDate = userData.joinDate || currentUser.metadata.creationTime;
            const daysActive = Math.floor((Date.now() - new Date(joinDate).getTime()) / (1000 * 60 * 60 * 24));
            document.getElementById('profileJoinDate').textContent = daysActive;
        }
    });
}

// Load User Posts
function loadUserPosts() {
    database.ref('posts').orderByChild('authorId').equalTo(currentUser.uid).on('value', (snapshot) => {
        userPosts = [];
        const posts = snapshot.val();
        
        if (posts) {
            Object.keys(posts).forEach(key => {
                userPosts.push({
                    id: key,
                    ...posts[key]
                });
            });
            
            // Sort by newest first
            userPosts.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        }
        
        displayUserPosts();
    });
}

// Display User Posts
function displayUserPosts() {
    const container = document.getElementById('userPosts');
    
    if (userPosts.length === 0) {
        container.innerHTML = `
            <div class="text-center py-5">
                <i class="fas fa-film display-1 text-muted"></i>
                <h4 class="mt-3 text-muted">Belum ada post</h4>
                <p class="text-muted">Mulai buat review anime pertama Anda!</p>
                <a href="dashboard.html" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Buat Post
                </a>
            </div>
        `;
        return;
    }
    
    container.innerHTML = userPosts.map(post => createPostCard(post)).join('');
}

// Load Liked Posts
function loadLikedPosts() {
    database.ref('posts').once('value', (snapshot) => {
        likedPosts = [];
        const posts = snapshot.val();
        
        if (posts) {
            Object.keys(posts).forEach(key => {
                const post = posts[key];
                if (post.likes && post.likes[currentUser.uid]) {
                    likedPosts.push({
                        id: key,
                        ...post
                    });
                }
            });
            
            // Sort by like date
            likedPosts.sort((a, b) => {
                const aLikeTime = a.likes[currentUser.uid].timestamp || 0;
                const bLikeTime = b.likes[currentUser.uid].timestamp || 0;
                return bLikeTime - aLikeTime;
            });
        }
        
        displayLikedPosts();
    });
}

// Display Liked Posts
function displayLikedPosts() {
    const container = document.getElementById('likedPosts');
    
    if (likedPosts.length === 0) {
        container.innerHTML = `
            <div class="text-center py-5">
                <i class="fas fa-heart display-1 text-muted"></i>
                <h4 class="mt-3 text-muted">Belum ada post yang disukai</h4>
                <p class="text-muted">Jelajahi dashboard untuk menemukan anime yang menarik!</p>
                <a href="dashboard.html" class="btn btn-primary">
                    <i class="fas fa-search"></i> Jelajahi
                </a>
            </div>
        `;
        return;
    }
    
    container.innerHTML = likedPosts.map(post => createPostCard(post)).join('');
}

// Create Post Card
function createPostCard(post) {
    const likesCount = Object.keys(post.likes || {}).length;
    const commentsCount = Object.keys(post.comments || {}).length;
    const timeAgo = formatTimeAgo(post.createdAt);
    
    return `
        <div class="card mb-3">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-8">
                        <h5 class="card-title">${post.title}</h5>
                        <div class="rating-display mb-2">
                            ${generateStarRating(post.rating)} 
                            <span class="fw-bold text-primary">${post.rating}/10</span>
                        </div>
                        <p class="card-text">${post.review.substring(0, 150)}${post.review.length > 150 ? '...' : ''}</p>
                        <small class="text-muted">${timeAgo} • ${likesCount} likes • ${commentsCount} comments</small>
                    </div>
                    <div class="col-md-4">
                        ${post.image ? `
                            <img src="${post.image}" alt="${post.title}" class="img-fluid rounded" style="max-height: 120px; object-fit: cover;">
                        ` : ''}
                    </div>
                </div>
            </div>
        </div>
    `;
}

// Load User Statistics
function loadUserStatistics() {
    // Calculate statistics from user posts
    let totalRating = 0;
    let genreCount = {};
    
    userPosts.forEach(post => {
        totalRating += post.rating;
        
        if (post.genre) {
            const genres = post.genre.split(',').map(g => g.trim());
            genres.forEach(genre => {
                genreCount[genre] = (genreCount[genre] || 0) + 1;
            });
        }
    });
    
    // Update statistics display
    document.getElementById('statsPostCount').textContent = userPosts.length;
    
    // Calculate total likes received
    let totalLikes = 0;
    userPosts.forEach(post => {
        totalLikes += Object.keys(post.likes || {}).length;
    });
    document.getElementById('statsLikeCount').textContent = totalLikes;
    
    // Average rating
    const avgRating = userPosts.length > 0 ? (totalRating / userPosts.length).toFixed(1) : 0;
    document.getElementById('statsAvgRating').textContent = avgRating;
    
    // Most reviewed genre
    const mostGenre = Object.keys(genreCount).reduce((a, b) => genreCount[a] > genreCount[b] ? a : b, '-');
    document.getElementById('statsMostGenre').textContent = mostGenre;
}

// Update Activity Chart
function updateActivityChart() {
    const ctx = document.getElementById('activityChart').getContext('2d');
    
    // Destroy existing chart if it exists
    if (activityChart) {
        activityChart.destroy();
    }
    
    // Prepare data for last 7 days
    const last7Days = [];
    const postCounts = [];
    
    for (let i = 6; i >= 0; i--) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        const dayName = date.toLocaleDateString('id-ID', { weekday: 'short' });
        last7Days.push(dayName);
        
        // Count posts for this day
        const dayStart = new Date(date);
        dayStart.setHours(0, 0, 0, 0);
        const dayEnd = new Date(date);
        dayEnd.setHours(23, 59, 59, 999);
        
        const postsThisDay = userPosts.filter(post => {
            const postDate = new Date(post.createdAt);
            return postDate >= dayStart && postDate <= dayEnd;
        }).length;
        
        postCounts.push(postsThisDay);
    }
    
    activityChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: last7Days,
            datasets: [{
                label: 'Posts',
                data: postCounts,
                borderColor: 'rgb(75, 192, 192)',
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                tension: 0.1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });
}

// Edit Profile
function editProfile() {
    // Load current data
    document.getElementById('editName').value = currentUser.displayName || '';
    
    database.ref(`users/${currentUser.uid}/bio`).once('value', (snapshot) => {
        document.getElementById('editBio').value = snapshot.val() || '';
    });
    
    editProfileModal.show();
}

// Handle Edit Profile
async function handleEditProfile(e) {
    e.preventDefault();
    
    const name = document.getElementById('editName').value.trim();
    const bio = document.getElementById('editBio').value.trim();
    
    if (!name) {
        showNotification('Nama harus diisi!', 'warning');
        return;
    }
    
    try {
        // Update Firebase Auth profile
        await currentUser.updateProfile({
            displayName: name
        });
        
        // Update user data in database
        await database.ref(`users/${currentUser.uid}`).update({
            name: name,
            bio: bio,
            lastUpdated: firebase.database.ServerValue.TIMESTAMP
        });
        
        // Update UI
        document.getElementById('profileUserName').textContent = name;
        document.getElementById('profileUserBio').textContent = bio || 'Pecinta anime sejati yang suka berbagi review';
        document.getElementById('userName').textContent = name;
        
        editProfileModal.hide();
        showNotification('Profile berhasil diperbarui!', 'success');
        
    } catch (error) {
        console.error('Error updating profile:', error);
        showNotification('Gagal memperbarui profile: ' + error.message, 'danger');
    }
}

// Generate Star Rating
function generateStarRating(rating) {
    const fullStars = Math.floor(rating);
    const halfStar = rating % 1 >= 0.5;
    const emptyStars = 5 - fullStars - (halfStar ? 1 : 0);
    
    let stars = '';
    
    for (let i = 0; i < fullStars; i++) {
        stars += '<i class="fas fa-star text-warning"></i>';
    }
    
    if (halfStar) {
        stars += '<i class="fas fa-star-half-alt text-warning"></i>';
    }
    
    for (let i = 0; i < emptyStars; i++) {
        stars += '<i class="far fa-star text-warning"></i>';
    }
    
    return stars;
}

// Format Time Ago
function formatTimeAgo(timestamp) {
    if (!timestamp) return 'Baru saja';
    
    const now = Date.now();
    const diff = now - timestamp;
    
    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    
    if (seconds < 60) return 'Baru saja';
    if (minutes < 60) return `${minutes} menit yang lalu`;
    if (hours < 24) return `${hours} jam yang lalu`;
    if (days < 7) return `${days} hari yang lalu`;
    
    return new Date(timestamp).toLocaleDateString('id-ID');
}

// Show Notification
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
    notification.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.parentNode.removeChild(notification);
        }
    }, 5000);
}

// Create Post (redirect to dashboard)
function showCreatePost() {
    window.location.href = 'dashboard.html';
}

// Logout Function
function logout() {
    auth.signOut().then(() => {
        showNotification('Logout berhasil!', 'success');
        setTimeout(() => {
            window.location.href = 'welcome.html';
        }, 1000);
    });
} 