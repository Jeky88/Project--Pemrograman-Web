// Konfigurasi Firebase
const firebaseConfig = {
    apiKey: "AIzaSyDrLa3Lu-CSO8az4XO42ixnCBU1toVFdsw",
    authDomain: "review-anime.firebaseapp.com",
    databaseURL: "https://review-anime-default-rtdb.asia-southeast1.firebasedatabase.app/",
    projectId: "review-anime",
    storageBucket: "review-anime.firebasestorage.app",
    messagingSenderId: "896892641219",
    appId: "1:896892641219:web:22c9cea128e5adf88d6776"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const database = firebase.database();

// Global variables
let currentUser = null; 