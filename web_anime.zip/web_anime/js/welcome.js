// Welcome Page JavaScript
let loginModal, registerModal;

document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM Content Loaded');
    
    // Check if Bootstrap is available
    if (typeof bootstrap === 'undefined') {
        console.error('Bootstrap is not loaded');
        return;
    }
    
    // Initialize modal elements after DOM is loaded
    try {
        const loginModalElement = document.getElementById('loginModal');
        const registerModalElement = document.getElementById('registerModal');
        
        if (loginModalElement && registerModalElement) {
            loginModal = new bootstrap.Modal(loginModalElement);
            registerModal = new bootstrap.Modal(registerModalElement);
            console.log('Modals initialized successfully');
        } else {
            console.error('Modal elements not found');
        }
    } catch (error) {
        console.error('Error initializing modals:', error);
    }
    
    // Check if user is already logged in
    if (typeof auth !== 'undefined') {
        auth.onAuthStateChanged((user) => {
            if (user) {
                // Redirect to dashboard if already logged in
                window.location.href = 'dashboard.html';
            }
        });
    } else {
        console.error('Firebase auth not available');
    }

    // Initialize animations
    initializeAnimations();
    loadFeaturedAnime();
    loadRecentReviews();
    initializeCounters();
    
    // Make functions globally available
    window.showLogin = showLogin;
    window.showRegister = showRegister;
    
    // Add event listeners to buttons as backup
    const loginButtons = document.querySelectorAll('[onclick="showLogin()"]');
    const registerButtons = document.querySelectorAll('[onclick="showRegister()"]');
    
    loginButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            showLogin();
        });
    });
    
    registerButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            showRegister();
        });
    });
    
    console.log('Event listeners added to buttons');
    
    // Add ESC key handler for modals
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            const openModals = document.querySelectorAll('.modal.show');
            openModals.forEach(modal => {
                if (loginModal && modal.id === 'loginModal') {
                    loginModal.hide();
                } else if (registerModal && modal.id === 'registerModal') {
                    registerModal.hide();
                } else {
                    hideModalManually(modal);
                }
            });
        }
    });
    
    // Add close button event listeners for manual modal handling
    const closeButtons = document.querySelectorAll('[data-bs-dismiss="modal"]');
    closeButtons.forEach(button => {
        button.addEventListener('click', function() {
            const modal = button.closest('.modal');
            if (modal) {
                if (loginModal && modal.id === 'loginModal') {
                    loginModal.hide();
                } else if (registerModal && modal.id === 'registerModal') {
                    registerModal.hide();
                } else {
                    // Manual fallback
                    hideModalManually(modal);
                }
                console.log('Modal closed');
            }
        });
    });
});

// Helper function to show modal manually
function showModalManually(modalElement) {
    // Create backdrop
    const backdrop = document.createElement('div');
    backdrop.className = 'modal-backdrop';
    backdrop.addEventListener('click', function() {
        hideModalManually(modalElement);
    });
    
    modalElement.style.display = 'block';
    modalElement.classList.add('show');
    document.body.classList.add('modal-open');
    document.body.appendChild(backdrop);
    
    // Store backdrop reference
    modalElement.backdrop = backdrop;
}

// Helper function to hide modal manually
function hideModalManually(modalElement) {
    modalElement.style.display = 'none';
    modalElement.classList.remove('show');
    document.body.classList.remove('modal-open');
    
    // Remove backdrop
    if (modalElement.backdrop) {
        document.body.removeChild(modalElement.backdrop);
        modalElement.backdrop = null;
    }
}

// Show Login Modal
function showLogin() {
    console.log('showLogin called');
    if (loginModal) {
        console.log('Opening login modal');
        loginModal.show();
    } else {
        console.error('Login modal not initialized');
        // Fallback: try to initialize modal on demand
        try {
            const loginModalElement = document.getElementById('loginModal');
            if (loginModalElement) {
                if (typeof bootstrap !== 'undefined') {
                    loginModal = new bootstrap.Modal(loginModalElement);
                    loginModal.show();
                    console.log('Login modal initialized and shown');
                } else {
                    // Manual fallback without Bootstrap
                    showModalManually(loginModalElement);
                    console.log('Login modal shown manually');
                }
            } else {
                console.error('Login modal element not found');
            }
        } catch (error) {
            console.error('Error with login modal:', error);
        }
    }
}

// Show Register Modal
function showRegister() {
    console.log('showRegister called');
    if (registerModal) {
        console.log('Opening register modal');
        registerModal.show();
    } else {
        console.error('Register modal not initialized');
        // Fallback: try to initialize modal on demand
        try {
            const registerModalElement = document.getElementById('registerModal');
            if (registerModalElement) {
                if (typeof bootstrap !== 'undefined') {
                    registerModal = new bootstrap.Modal(registerModalElement);
                    registerModal.show();
                    console.log('Register modal initialized and shown');
                } else {
                    // Manual fallback without Bootstrap
                    showModalManually(registerModalElement);
                    console.log('Register modal shown manually');
                }
            } else {
                console.error('Register modal element not found');
            }
        } catch (error) {
            console.error('Error with register modal:', error);
        }
    }
}

// Login Form Handler
document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    
    try {
        await auth.signInWithEmailAndPassword(email, password);
        
        // Hide modal using appropriate method
        if (loginModal) {
            loginModal.hide();
        } else {
            const loginModalElement = document.getElementById('loginModal');
            if (loginModalElement) {
                hideModalManually(loginModalElement);
            }
        }
        
        showNotification('Login berhasil! Mengarahkan ke dashboard...', 'success');
        
        // Redirect to dashboard after short delay
        setTimeout(() => {
            window.location.href = 'dashboard.html';
        }, 1500);
        
    } catch (error) {
        console.error('Login error:', error);
        let errorMessage = 'Login gagal: ';
        
        switch (error.code) {
            case 'auth/user-not-found':
                errorMessage += 'Email tidak terdaftar';
                break;
            case 'auth/wrong-password':
                errorMessage += 'Password salah';
                break;
            case 'auth/invalid-email':
                errorMessage += 'Format email tidak valid';
                break;
            case 'auth/user-disabled':
                errorMessage += 'Akun telah dinonaktifkan';
                break;
            default:
                errorMessage += error.message;
        }
        
        showNotification(errorMessage, 'danger');
    }
});

// Register Form Handler
document.getElementById('registerForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const name = document.getElementById('registerName').value;
    const email = document.getElementById('registerEmail').value;
    const password = document.getElementById('registerPassword').value;
    const confirmPassword = document.getElementById('registerConfirmPassword').value;
    
    if (password !== confirmPassword) {
        showNotification('Password tidak cocok!', 'danger');
        return;
    }
    
    if (password.length < 6) {
        showNotification('Password harus minimal 6 karakter!', 'danger');
        return;
    }
    
    try {
        const userCredential = await auth.createUserWithEmailAndPassword(email, password);
        
        // Update user profile
        await userCredential.user.updateProfile({
            displayName: name
        });
        
        // Save user profile to database
        try {
            await database.ref('users/' + userCredential.user.uid).set({
                name: name,
                email: email,
                createdAt: firebase.database.ServerValue.TIMESTAMP,
                postCount: 0,
                likeCount: 0,
                commentCount: 0
            });
        } catch (dbError) {
            console.warn('Could not save user profile to database:', dbError.message);
        }
        
        // Hide modal using appropriate method
        if (registerModal) {
            registerModal.hide();
        } else {
            const registerModalElement = document.getElementById('registerModal');
            if (registerModalElement) {
                hideModalManually(registerModalElement);
            }
        }
        
        showNotification('Registrasi berhasil! Mengarahkan ke dashboard...', 'success');
        
        // Redirect to dashboard after short delay
        setTimeout(() => {
            window.location.href = 'dashboard.html';
        }, 1500);
        
    } catch (error) {
        console.error('Registration error:', error);
        let errorMessage = 'Registrasi gagal: ';
        
        switch (error.code) {
            case 'auth/email-already-in-use':
                errorMessage += 'Email sudah digunakan';
                break;
            case 'auth/invalid-email':
                errorMessage += 'Format email tidak valid';
                break;
            case 'auth/weak-password':
                errorMessage += 'Password terlalu lemah';
                break;
            case 'auth/operation-not-allowed':
                errorMessage += 'Email/Password authentication belum diaktifkan di Firebase Console';
                break;
            default:
                errorMessage += error.message;
        }
        
        showNotification(errorMessage, 'danger');
    }
});

// Initialize Animations
function initializeAnimations() {
    // Floating anime cards animation
    const floatingCards = document.querySelectorAll('.anime-card-float');
    floatingCards.forEach((card, index) => {
        card.style.animationDelay = `${index * 0.5}s`;
    });
    
    // Scroll animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in');
            }
        });
    }, observerOptions);
    
    // Observe all cards
    document.querySelectorAll('.card').forEach(card => {
        observer.observe(card);
    });
}

// Load Featured Anime
function loadFeaturedAnime() {
    // This would normally load from database
    // For now, we'll use static data
    const featuredAnime = [
        {
            title: "Attack on Titan",
            rating: 9.2,
            likes: 1500,
            comments: 234,
            shares: 89,
            description: "Epic anime dengan cerita yang kompleks dan karakter yang berkembang..."
        },
        {
            title: "Demon Slayer",
            rating: 8.8,
            likes: 1200,
            comments: 189,
            shares: 67,
            description: "Animasi yang indah dengan fight scene yang memukau..."
        },
        {
            title: "Your Name",
            rating: 9.8,
            likes: 2100,
            comments: 345,
            shares: 123,
            description: "Masterpiece dari Makoto Shinkai yang menyentuh hati..."
        }
    ];
    
    // Update the featured anime section with real data if needed
    console.log('Featured anime loaded:', featuredAnime);
}

// Load Recent Reviews
function loadRecentReviews() {
    database.ref('reviews').orderByChild('createdAt').limitToLast(5).once('value', (snapshot) => {
        const reviews = snapshot.val();
        if (reviews) {
            const recentReviewsContainer = document.getElementById('recentReviews');
            const reviewsArray = Object.keys(reviews).map(key => ({
                id: key,
                ...reviews[key]
            }));
            
            // Sort by newest first
            reviewsArray.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
            
            // Update the recent reviews section
            recentReviewsContainer.innerHTML = reviewsArray.map(review => `
                <div class="col-12 mb-4">
                    <div class="card review-preview-card">
                        <div class="card-body">
                            <div class="d-flex align-items-center mb-3">
                                <div class="user-avatar">
                                    <i class="fas fa-user-circle display-6 text-primary"></i>
                                </div>
                                <div class="ms-3">
                                    <h6 class="mb-0">${review.authorName}</h6>
                                    <small class="text-muted">${formatDate(review.createdAt)}</small>
                                </div>
                                <div class="ms-auto">
                                    <div class="rating-stars">
                                        ${generateStars(review.rating)} <span class="text-muted">${review.rating}/10</span>
                                    </div>
                                </div>
                            </div>
                            <h5 class="card-title">${review.title}</h5>
                            <p class="card-text">${review.review.substring(0, 150)}...</p>
                            <div class="review-stats">
                                <span><i class="fas fa-heart text-danger"></i> ${review.likes || 0}</span>
                                <span><i class="fas fa-comment text-info"></i> ${Object.keys(review.comments || {}).length}</span>
                                <span><i class="fas fa-share text-success"></i> ${review.shares || 0}</span>
                            </div>
                        </div>
                    </div>
                </div>
            `).join('');
        }
    });
}

// Initialize Counters Animation
function initializeCounters() {
    const counters = document.querySelectorAll('.counter');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const counter = entry.target;
                const target = parseInt(counter.getAttribute('data-target'));
                const increment = target / 100;
                let current = 0;
                
                const timer = setInterval(() => {
                    current += increment;
                    counter.textContent = Math.floor(current);
                    
                    if (current >= target) {
                        counter.textContent = target;
                        clearInterval(timer);
                    }
                }, 20);
                
                observer.unobserve(counter);
            }
        });
    });
    
    counters.forEach(counter => {
        observer.observe(counter);
    });
}

// Generate star rating
function generateStars(rating) {
    const fullStars = Math.floor(rating);
    const halfStar = rating % 1 !== 0;
    const emptyStars = 5 - Math.ceil(rating / 2);
    
    let stars = '';
    
    for (let i = 0; i < fullStars && i < 5; i++) {
        stars += '★';
    }
    
    if (halfStar && fullStars < 5) {
        stars += '☆';
    }
    
    for (let i = 0; i < emptyStars && stars.length < 5; i++) {
        stars += '☆';
    }
    
    return stars;
}

// Format date
function formatDate(timestamp) {
    if (!timestamp) return 'Baru saja';
    
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now - date;
    
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    
    if (minutes < 1) return 'Baru saja';
    if (minutes < 60) return `${minutes} menit yang lalu`;
    if (hours < 24) return `${hours} jam yang lalu`;
    if (days < 7) return `${days} hari yang lalu`;
    
    return date.toLocaleDateString('id-ID');
}

// Show Notification
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
    notification.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.parentNode.removeChild(notification);
        }
    }, 5000);
}

// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const href = this.getAttribute('href');
        if (href && href !== '#') {
            const target = document.querySelector(href);
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        }
    });
}); 