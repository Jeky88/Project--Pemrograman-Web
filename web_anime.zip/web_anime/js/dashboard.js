// Dashboard JavaScript - Full Functionality
let allPosts = [];
let filteredPosts = [];
let currentFilter = 'all';
let currentPage = 1;
const postsPerPage = 10;

// DOM Elements
const createPostModal = new bootstrap.Modal(document.getElementById('createPostModal'));
const postsFeed = document.getElementById('postsFeed');
const searchInput = document.getElementById('searchInput');
const filterSelect = document.getElementById('filterSelect');

// Initialize Dashboard
document.addEventListener('DOMContentLoaded', function() {
    // Initialize dark mode
    initializeDarkMode();
    
    // Check authentication
    auth.onAuthStateChanged((user) => {
        if (user) {
            currentUser = user;
            initializeDashboard();
        } else {
            // Redirect to welcome page if not authenticated
            window.location.href = 'welcome.html';
        }
    });
});

// Initialize Dashboard Functions
function initializeDashboard() {
    loadUserProfile();
    loadAllPosts();
    loadTrendingAnime();
    loadTopReviewers();
    loadRecentActivity();
    loadFollowingData();
    setupEventListeners();
    initializeLazyLoading();
}

// Load User Profile
function loadUserProfile() {
    const userName = currentUser.displayName || currentUser.email;
    const userEmail = currentUser.email;
    
    // Update navigation
    document.getElementById('userName').textContent = userName;
    
    // Update sidebar
    document.getElementById('sidebarUserName').textContent = userName;
    document.getElementById('sidebarUserEmail').textContent = userEmail;
    
    // Load user stats from database
    database.ref(`users/${currentUser.uid}`).once('value', (snapshot) => {
        const userData = snapshot.val();
        if (userData) {
            document.getElementById('userPostCount').textContent = userData.postCount || 0;
            document.getElementById('userLikeCount').textContent = userData.likeCount || 0;
            document.getElementById('userCommentCount').textContent = userData.commentCount || 0;
        }
    });
}

// Show Create Post Modal
function showCreatePost() {
    createPostModal.show();
}

// Update Rating Display
function updateRatingDisplay() {
    const rating = document.getElementById('animeRating').value;
    document.getElementById('ratingDisplay').textContent = rating;
}

// Setup Event Listeners
function setupEventListeners() {
    // Create Post Form
    document.getElementById('createPostForm').addEventListener('submit', handleCreatePost);
    
    // Search Input
    searchInput.addEventListener('input', debounce(handleSearch, 300));
    
    // Filter Select
    filterSelect.addEventListener('change', handleFilter);
    
    // Rating slider
    document.getElementById('animeRating').addEventListener('input', updateRatingDisplay);
    
    // Advanced Search Event Listeners
    document.getElementById('minRating').addEventListener('input', updateRatingRangeDisplay);
    document.getElementById('maxRating').addEventListener('input', updateRatingRangeDisplay);
    
    // Auto-apply filters when changed
    document.getElementById('genreFilter').addEventListener('change', applyAdvancedSearch);
    document.getElementById('dateFilter').addEventListener('change', applyAdvancedSearch);
    document.getElementById('sortOrder').addEventListener('change', applyAdvancedSearch);
    document.getElementById('hasImageFilter').addEventListener('change', applyAdvancedSearch);
    document.getElementById('mergedReviewsFilter').addEventListener('change', applyAdvancedSearch);
}

// Handle Create Post
async function handleCreatePost(e) {
    e.preventDefault();
    
    const title = document.getElementById('animeTitle').value.trim();
    const genre = document.getElementById('animeGenre').value.trim();
    const rating = parseInt(document.getElementById('animeRating').value);
    const review = document.getElementById('animeReview').value.trim();
    const allowMerge = document.getElementById('allowMerge').checked;
    const imageFile = document.getElementById('animeImage').files[0];
    
    if (!title || !review) {
        showNotification('Judul anime dan review harus diisi!', 'warning');
        return;
    }
    
    try {
        // Convert image to base64 if exists
        let imageBase64 = '';
        if (imageFile) {
            imageBase64 = await convertToBase64(imageFile);
            
            // Validate image size (max 2MB)
            if (imageBase64.length > 2 * 1024 * 1024) {
                showNotification('Ukuran gambar terlalu besar! Maksimal 2MB', 'warning');
                return;
            }
        }
        
        // Check if anime already exists for merging
        let existingAnimeId = null;
        if (allowMerge) {
            existingAnimeId = await findExistingAnime(title);
        }
        
        const postData = {
            title: title,
            genre: genre,
            rating: rating,
            review: review,
            image: imageBase64,
            authorId: currentUser.uid,
            authorName: currentUser.displayName || currentUser.email,
            createdAt: firebase.database.ServerValue.TIMESTAMP,
            likes: {},
            comments: {},
            shares: 0,
            allowMerge: allowMerge
        };
        
        if (existingAnimeId && allowMerge) {
            // Merge with existing anime
            await mergeAnimeRating(existingAnimeId, postData);
        } else {
            // Create new post
            await database.ref('posts').push(postData);
        }
        
        // Update user post count
        await updateUserStats('postCount', 1);
        
        // Reset form and close modal
        document.getElementById('createPostForm').reset();
        document.getElementById('ratingDisplay').textContent = '5';
        createPostModal.hide();
        
        showNotification('Post berhasil dibuat!', 'success');
        
        // Reload posts
        loadAllPosts();
        
    } catch (error) {
        console.error('Error creating post:', error);
        showNotification('Gagal membuat post: ' + error.message, 'danger');
    }
}

// Convert image to base64
function convertToBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result);
        reader.onerror = error => reject(error);
    });
}

// Find existing anime for merging
async function findExistingAnime(title) {
    const snapshot = await database.ref('posts').orderByChild('title').equalTo(title).once('value');
    const posts = snapshot.val();
    
    if (posts) {
        const postIds = Object.keys(posts);
        return postIds[0]; // Return first matching anime
    }
    
    return null;
}

// Merge anime rating
async function mergeAnimeRating(existingAnimeId, newPostData) {
    const existingPostSnapshot = await database.ref(`posts/${existingAnimeId}`).once('value');
    const existingPost = existingPostSnapshot.val();
    
    if (existingPost) {
        // Calculate new average rating
        const existingRating = existingPost.rating || 0;
        const existingReviewCount = existingPost.reviewCount || 1;
        const newReviewCount = existingReviewCount + 1;
        const newAverageRating = ((existingRating * existingReviewCount) + newPostData.rating) / newReviewCount;
        
        // Update existing post with merged data
        const updates = {
            rating: Math.round(newAverageRating * 10) / 10, // Round to 1 decimal
            reviewCount: newReviewCount,
            lastUpdated: firebase.database.ServerValue.TIMESTAMP
        };
        
        // Add new review to merged reviews
        if (!existingPost.mergedReviews) {
            updates.mergedReviews = {};
        }
        
        const newReviewKey = database.ref().child('posts').child(existingAnimeId).child('mergedReviews').push().key;
        updates[`mergedReviews/${newReviewKey}`] = {
            review: newPostData.review,
            rating: newPostData.rating,
            authorId: newPostData.authorId,
            authorName: newPostData.authorName,
            createdAt: firebase.database.ServerValue.TIMESTAMP
        };
        
        await database.ref(`posts/${existingAnimeId}`).update(updates);
        
        showNotification('Review berhasil digabung dengan anime yang sudah ada!', 'info');
    }
}

// Load All Posts
function loadAllPosts() {
    showLoading();
    
    database.ref('posts').orderByChild('createdAt').on('value', (snapshot) => {
        allPosts = [];
        const posts = snapshot.val();
        
        if (posts) {
            Object.keys(posts).forEach(key => {
                allPosts.push({
                    id: key,
                    ...posts[key]
                });
            });
            
            // Sort by newest first
            allPosts.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        }
        
        applyCurrentFilter();
        hideLoading();
    });
}



// Handle Search
function handleSearch() {
    const searchTerm = searchInput.value.toLowerCase().trim();
    
    if (!searchTerm) {
        applyCurrentFilter();
        return;
    }
    
    filteredPosts = allPosts.filter(post => {
        const titleMatch = post.title.toLowerCase().includes(searchTerm);
        const genreMatch = post.genre && post.genre.toLowerCase().includes(searchTerm);
        const reviewMatch = post.review.toLowerCase().includes(searchTerm);
        const authorMatch = post.authorName.toLowerCase().includes(searchTerm);
        
        return titleMatch || genreMatch || reviewMatch || authorMatch;
    });
    
    displayPosts();
}

// Handle Filter
function handleFilter() {
    currentFilter = filterSelect.value;
    applyCurrentFilter();
}



// Create Post HTML
function createPostHTML(post) {
    const likesCount = Object.keys(post.likes || {}).length;
    const commentsCount = Object.keys(post.comments || {}).length;
    const isLiked = post.likes && post.likes[currentUser.uid];
    const timeAgo = formatTimeAgo(post.createdAt);
    
    return `
        <div class="card post-card" data-post-id="${post.id}">
            <div class="card-body">
                <!-- Post Header -->
                <div class="post-header">
                    <div class="post-author-avatar">
                        ${post.authorName.charAt(0).toUpperCase()}
                    </div>
                    <div class="post-meta">
                        <h6 class="mb-0">${post.authorName}</h6>
                        <small class="text-muted">${timeAgo}</small>
                    </div>
                    <div class="d-flex align-items-center">
                        ${post.authorId !== currentUser.uid ? `
                            <button class="btn btn-sm btn-outline-primary me-2" onclick="toggleFollow('${post.authorId}', '${post.authorName}')" id="follow-btn-${post.authorId}">
                                <i class="fas fa-user-plus"></i> <span>Follow</span>
                            </button>
                        ` : ''}
                        <div class="dropdown">
                            <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                <i class="fas fa-ellipsis-h"></i>
                            </button>
                            <ul class="dropdown-menu">
                                ${post.authorId === currentUser.uid ? `
                                    <li><a class="dropdown-item" href="#" onclick="editPost('${post.id}')"><i class="fas fa-edit"></i> Edit</a></li>
                                    <li><a class="dropdown-item text-danger" href="#" onclick="deletePost('${post.id}')"><i class="fas fa-trash"></i> Hapus</a></li>
                                ` : `
                                    <li><a class="dropdown-item" href="#" onclick="viewUserProfile('${post.authorId}')"><i class="fas fa-user"></i> Lihat Profile</a></li>
                                    <li><a class="dropdown-item" href="#" onclick="reportPost('${post.id}')"><i class="fas fa-flag"></i> Laporkan</a></li>
                                `}
                            </ul>
                        </div>
                    </div>
                </div>
                
                <!-- Post Content -->
                <div class="post-content">
                    <h5 class="mb-2">${post.title}</h5>
                    <div class="rating-display mb-2">
                        ${generateStarRating(post.rating)} 
                        <span class="fw-bold text-primary">${post.rating}/10</span>
                        ${post.reviewCount > 1 ? `<small class="text-muted">(${post.reviewCount} reviews)</small>` : ''}
                    </div>
                    ${post.genre ? `
                        <div class="genre-tags mb-2">
                            ${post.genre.split(',').map(g => `<span class="badge bg-secondary me-1">${g.trim()}</span>`).join('')}
                        </div>
                    ` : ''}
                    <p class="mb-3">${post.review}</p>
                    ${post.image ? `
                        <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='400' height='300'%3E%3Crect width='100%25' height='100%25' fill='%23f8f9fa'/%3E%3Ctext x='50%25' y='50%25' text-anchor='middle' dy='.3em' fill='%23666'%3ELoading...%3C/text%3E%3C/svg%3E" 
                             data-src="${post.image}" 
                             alt="${post.title}" 
                             class="post-image lazy-load" 
                             onclick="showImageModal('${post.image}', '${post.title}')">
                    ` : ''}
                </div>
                
                <!-- Post Actions -->
                <div class="post-actions">
                    <div class="action-buttons">
                        <button class="action-btn ${isLiked ? 'liked' : ''}" onclick="toggleLike('${post.id}')">
                            <i class="fas fa-heart"></i> <span>${likesCount}</span>
                        </button>
                        <button class="action-btn" onclick="toggleComments('${post.id}')">
                            <i class="fas fa-comment"></i> <span>${commentsCount}</span>
                        </button>
                        <button class="action-btn" onclick="sharePost('${post.id}')">
                            <i class="fas fa-share"></i> <span>${post.shares || 0}</span>
                        </button>
                    </div>
                    <div class="post-stats">
                        ${likesCount > 0 ? `${likesCount} likes` : ''} 
                        ${commentsCount > 0 ? `${commentsCount} comments` : ''}
                    </div>
                </div>
                
                <!-- Comments Section -->
                <div class="comments-section d-none" id="comments-${post.id}">
                    <div class="comments-list" id="comments-list-${post.id}">
                        ${displayComments(post.comments || {})}
                    </div>
                    <div class="comment-form mt-3">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Tulis komentar..." id="comment-input-${post.id}" onkeypress="handleCommentKeyPress(event, '${post.id}')">
                            <button class="btn btn-primary" onclick="addComment('${post.id}')">
                                <i class="fas fa-paper-plane"></i>
                            </button>
                        </div>
                    </div>
                </div>
                
                <!-- Merged Reviews (if any) -->
                ${post.mergedReviews ? `
                    <div class="merged-reviews mt-3">
                        <button class="btn btn-outline-info btn-sm" onclick="toggleMergedReviews('${post.id}')">
                            <i class="fas fa-layer-group"></i> Lihat ${Object.keys(post.mergedReviews).length} review lainnya
                        </button>
                        <div class="merged-reviews-list d-none" id="merged-reviews-${post.id}">
                            ${displayMergedReviews(post.mergedReviews)}
                        </div>
                    </div>
                ` : ''}
            </div>
        </div>
    `;
}

// Generate Star Rating
function generateStarRating(rating) {
    const fullStars = Math.floor(rating);
    const halfStar = rating % 1 >= 0.5;
    const emptyStars = 5 - fullStars - (halfStar ? 1 : 0);
    
    let stars = '';
    
    for (let i = 0; i < fullStars; i++) {
        stars += '<i class="fas fa-star text-warning"></i>';
    }
    
    if (halfStar) {
        stars += '<i class="fas fa-star-half-alt text-warning"></i>';
    }
    
    for (let i = 0; i < emptyStars; i++) {
        stars += '<i class="far fa-star text-warning"></i>';
    }
    
    return stars;
}

// Toggle Like
async function toggleLike(postId) {
    try {
        const likePath = `posts/${postId}/likes/${currentUser.uid}`;
        const snapshot = await database.ref(likePath).once('value');
        
        if (snapshot.exists()) {
            // Unlike
            await database.ref(likePath).remove();
            await updateUserStats('likeCount', -1);
        } else {
            // Like
            await database.ref(likePath).set({
                timestamp: firebase.database.ServerValue.TIMESTAMP,
                userName: currentUser.displayName || currentUser.email
            });
            await updateUserStats('likeCount', 1);
        }
        
        // Update UI immediately
        const button = document.querySelector(`[onclick="toggleLike('${postId}')"]`);
        if (button) {
            button.classList.toggle('liked');
            const countSpan = button.querySelector('span');
            let count = parseInt(countSpan.textContent) || 0;
            countSpan.textContent = snapshot.exists() ? count - 1 : count + 1;
        }
        
    } catch (error) {
        console.error('Error toggling like:', error);
        showNotification('Gagal mengubah like: ' + error.message, 'danger');
    }
}

// Toggle Comments
function toggleComments(postId) {
    const commentsSection = document.getElementById(`comments-${postId}`);
    commentsSection.classList.toggle('d-none');
    
    if (!commentsSection.classList.contains('d-none')) {
        // Focus on comment input
        document.getElementById(`comment-input-${postId}`).focus();
    }
}

// Handle Comment Key Press
function handleCommentKeyPress(event, postId) {
    if (event.key === 'Enter') {
        addComment(postId);
    }
}

// Add Comment
async function addComment(postId) {
    const commentInput = document.getElementById(`comment-input-${postId}`);
    const commentText = commentInput.value.trim();
    
    if (!commentText) {
        showNotification('Komentar tidak boleh kosong!', 'warning');
        return;
    }
    
    try {
        const commentData = {
            text: commentText,
            authorId: currentUser.uid,
            authorName: currentUser.displayName || currentUser.email,
            createdAt: firebase.database.ServerValue.TIMESTAMP
        };
        
        await database.ref(`posts/${postId}/comments`).push(commentData);
        await updateUserStats('commentCount', 1);
        
        commentInput.value = '';
        showNotification('Komentar berhasil ditambahkan!', 'success');
        
    } catch (error) {
        console.error('Error adding comment:', error);
        showNotification('Gagal menambahkan komentar: ' + error.message, 'danger');
    }
}

// Display Comments
function displayComments(comments) {
    if (!comments || Object.keys(comments).length === 0) {
        return '<p class="text-muted">Belum ada komentar</p>';
    }
    
    const commentsArray = Object.keys(comments).map(key => ({
        id: key,
        ...comments[key]
    }));
    
    // Sort by newest first
    commentsArray.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    
    return commentsArray.map(comment => `
        <div class="comment mb-2">
            <div class="d-flex">
                <div class="comment-avatar me-2">
                    <div class="bg-secondary rounded-circle d-flex align-items-center justify-content-center" style="width: 32px; height: 32px; font-size: 0.8rem; color: white;">
                        ${comment.authorName.charAt(0).toUpperCase()}
                    </div>
                </div>
                <div class="comment-content flex-grow-1">
                    <div class="comment-header">
                        <strong>${comment.authorName}</strong>
                        <small class="text-muted ms-2">${formatTimeAgo(comment.createdAt)}</small>
                    </div>
                    <div class="comment-text">${comment.text}</div>
                </div>
            </div>
        </div>
    `).join('');
}

// Display Merged Reviews
function displayMergedReviews(mergedReviews) {
    const reviewsArray = Object.keys(mergedReviews).map(key => ({
        id: key,
        ...mergedReviews[key]
    }));
    
    return reviewsArray.map(review => `
        <div class="merged-review mt-2 p-3 bg-light rounded">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <strong>${review.authorName}</strong>
                <div>
                    ${generateStarRating(review.rating)} <span class="fw-bold">${review.rating}/10</span>
                </div>
            </div>
            <p class="mb-1">${review.review}</p>
            <small class="text-muted">${formatTimeAgo(review.createdAt)}</small>
        </div>
    `).join('');
}

// Toggle Merged Reviews
function toggleMergedReviews(postId) {
    const mergedReviewsList = document.getElementById(`merged-reviews-${postId}`);
    mergedReviewsList.classList.toggle('d-none');
}

// Share Post
async function sharePost(postId) {
    try {
        // Increment share count
        await database.ref(`posts/${postId}/shares`).transaction((currentShares) => {
            return (currentShares || 0) + 1;
        });
        
        // Update UI
        const shareButton = document.querySelector(`[onclick="sharePost('${postId}')"] span`);
        if (shareButton) {
            const currentCount = parseInt(shareButton.textContent) || 0;
            shareButton.textContent = currentCount + 1;
        }
        
        // Copy link to clipboard
        const postUrl = `${window.location.origin}${window.location.pathname}?post=${postId}`;
        await navigator.clipboard.writeText(postUrl);
        
        showNotification('Link post berhasil disalin!', 'success');
        
    } catch (error) {
        console.error('Error sharing post:', error);
        showNotification('Gagal membagikan post: ' + error.message, 'danger');
    }
}



// Update User Stats
async function updateUserStats(statType, increment) {
    try {
        await database.ref(`users/${currentUser.uid}/${statType}`).transaction((currentValue) => {
            return Math.max(0, (currentValue || 0) + increment);
        });
        
        // Update UI
        const statElement = document.getElementById(`user${statType.charAt(0).toUpperCase() + statType.slice(1)}`);
        if (statElement) {
            const currentValue = parseInt(statElement.textContent) || 0;
            statElement.textContent = Math.max(0, currentValue + increment);
        }
        
    } catch (error) {
        console.error('Error updating user stats:', error);
    }
}

// Load Trending Anime
function loadTrendingAnime() {
    // Get top anime by likes and recent activity
    database.ref('posts').orderByChild('createdAt').limitToLast(20).once('value', (snapshot) => {
        const posts = snapshot.val();
        if (posts) {
            const animeMap = new Map();
            
            Object.values(posts).forEach(post => {
                const key = post.title.toLowerCase();
                if (animeMap.has(key)) {
                    const existing = animeMap.get(key);
                    existing.totalLikes += Object.keys(post.likes || {}).length;
                    existing.totalReviews += 1;
                    existing.avgRating = (existing.avgRating * (existing.totalReviews - 1) + post.rating) / existing.totalReviews;
                } else {
                    animeMap.set(key, {
                        title: post.title,
                        totalLikes: Object.keys(post.likes || {}).length,
                        totalReviews: 1,
                        avgRating: post.rating,
                        image: post.image
                    });
                }
            });
            
            // Sort by popularity (likes + reviews)
            const trending = Array.from(animeMap.values())
                .sort((a, b) => (b.totalLikes + b.totalReviews) - (a.totalLikes + a.totalReviews))
                .slice(0, 5);
            
            displayTrendingAnime(trending);
        }
    });
}

// Display Trending Anime
function displayTrendingAnime(trending) {
    const container = document.getElementById('trendingAnime');
    
    if (trending.length === 0) {
        container.innerHTML = '<p class="text-muted">Belum ada data trending</p>';
        return;
    }
    
    container.innerHTML = trending.map((anime, index) => `
        <div class="trending-item">
            <div class="trending-rank fw-bold text-primary">#${index + 1}</div>
            <div class="trending-anime-info">
                <h6>${anime.title}</h6>
                <small class="text-muted">
                    ${generateStarRating(anime.avgRating)} ${anime.avgRating.toFixed(1)}/10 
                    • ${anime.totalReviews} reviews • ${anime.totalLikes} likes
                </small>
            </div>
        </div>
    `).join('');
}

// Load Top Reviewers
function loadTopReviewers() {
    database.ref('users').orderByChild('postCount').limitToLast(5).once('value', (snapshot) => {
        const users = snapshot.val();
        if (users) {
            const topReviewers = Object.values(users)
                .sort((a, b) => (b.postCount || 0) - (a.postCount || 0))
                .slice(0, 5);
            
            displayTopReviewers(topReviewers);
        }
    });
}

// Display Top Reviewers
function displayTopReviewers(reviewers) {
    const container = document.getElementById('topReviewers');
    
    if (reviewers.length === 0) {
        container.innerHTML = '<p class="text-muted">Belum ada data reviewer</p>';
        return;
    }
    
    container.innerHTML = reviewers.map((reviewer, index) => `
        <div class="reviewer-item">
            <div class="reviewer-rank fw-bold text-warning">#${index + 1}</div>
            <div class="reviewer-info">
                <h6>${reviewer.name}</h6>
                <small class="text-muted">
                    ${reviewer.postCount || 0} posts • ${reviewer.likeCount || 0} likes
                </small>
            </div>
        </div>
    `).join('');
}

// Load Recent Activity
function loadRecentActivity() {
    // Load recent comments and likes
    database.ref('posts').orderByChild('createdAt').limitToLast(10).once('value', (snapshot) => {
        const posts = snapshot.val();
        const activities = [];
        
        if (posts) {
            Object.entries(posts).forEach(([postId, post]) => {
                // Add recent comments
                if (post.comments) {
                    Object.values(post.comments).forEach(comment => {
                        activities.push({
                            type: 'comment',
                            user: comment.authorName,
                            target: post.title,
                            time: comment.createdAt
                        });
                    });
                }
                
                // Add recent likes
                if (post.likes) {
                    Object.values(post.likes).forEach(like => {
                        activities.push({
                            type: 'like',
                            user: like.userName,
                            target: post.title,
                            time: like.timestamp
                        });
                    });
                }
            });
        }
        
        // Sort by newest first and limit to 10
        activities.sort((a, b) => (b.time || 0) - (a.time || 0));
        displayRecentActivity(activities.slice(0, 10));
    });
}

// Display Recent Activity
function displayRecentActivity(activities) {
    const container = document.getElementById('recentActivity');
    
    if (activities.length === 0) {
        container.innerHTML = '<p class="text-muted">Belum ada aktivitas</p>';
        return;
    }
    
    container.innerHTML = activities.map(activity => `
        <div class="activity-item">
            <div class="activity-icon">
                <i class="fas fa-${activity.type === 'like' ? 'heart text-danger' : 'comment text-info'}"></i>
            </div>
            <div class="activity-info">
                <h6>${activity.user}</h6>
                <small class="text-muted">
                    ${activity.type === 'like' ? 'menyukai' : 'berkomentar di'} "${activity.target}"
                    • ${formatTimeAgo(activity.time)}
                </small>
            </div>
        </div>
    `).join('');
}

// Quick Action Functions
function showTopAnime() {
    filterSelect.value = 'highest-rated';
    handleFilter();
    showNotification('Menampilkan anime dengan rating tertinggi', 'info');
}

function showMyReviews() {
    filteredPosts = allPosts.filter(post => post.authorId === currentUser.uid);
    displayPosts();
    showNotification('Menampilkan review Anda', 'info');
}

// Utility Functions
function formatTimeAgo(timestamp) {
    if (!timestamp) return 'Baru saja';
    
    const now = Date.now();
    const diff = now - timestamp;
    
    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    
    if (seconds < 60) return 'Baru saja';
    if (minutes < 60) return `${minutes} menit yang lalu`;
    if (hours < 24) return `${hours} jam yang lalu`;
    if (days < 7) return `${days} hari yang lalu`;
    
    return new Date(timestamp).toLocaleDateString('id-ID');
}

function showLoading() {
    postsFeed.innerHTML = `
        <div class="text-center py-5">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
            <p class="mt-3 text-muted">Memuat posts...</p>
        </div>
    `;
}

function hideLoading() {
    // Loading will be replaced by posts
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Show Notification
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
    notification.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.parentNode.removeChild(notification);
        }
    }, 5000);
}

// Show Image Modal
function showImageModal(imageSrc, title) {
    const imageModal = new bootstrap.Modal(document.getElementById('imageModal'));
    document.getElementById('imageModalImg').src = imageSrc;
    document.getElementById('imageModalTitle').textContent = title;
    imageModal.show();
}

// Edit Post (placeholder)
function editPost(postId) {
    showNotification('Fitur edit post akan segera tersedia!', 'info');
}

// Delete Post
async function deletePost(postId) {
    if (!confirm('Yakin ingin menghapus post ini?')) {
        return;
    }
    
    try {
        await database.ref(`posts/${postId}`).remove();
        showNotification('Post berhasil dihapus!', 'success');
    } catch (error) {
        console.error('Error deleting post:', error);
        showNotification('Gagal menghapus post: ' + error.message, 'danger');
    }
}

// Report Post (placeholder)
function reportPost(postId) {
    showNotification('Laporan telah dikirim. Terima kasih!', 'info');
}

// Advanced Search Functions
function toggleAdvancedSearch() {
    const panel = document.getElementById('advancedSearchPanel');
    panel.classList.toggle('d-none');
}

function updateRatingRangeDisplay() {
    const minRating = document.getElementById('minRating').value;
    const maxRating = document.getElementById('maxRating').value;
    
    // Ensure min is not greater than max
    if (parseInt(minRating) > parseInt(maxRating)) {
        document.getElementById('minRating').value = maxRating;
    }
    
    document.getElementById('minRatingDisplay').textContent = document.getElementById('minRating').value;
    document.getElementById('maxRatingDisplay').textContent = document.getElementById('maxRating').value;
    
    // Auto-apply if panel is open
    if (!document.getElementById('advancedSearchPanel').classList.contains('d-none')) {
        applyAdvancedSearch();
    }
}

function clearAdvancedFilters() {
    document.getElementById('genreFilter').value = '';
    document.getElementById('minRating').value = 1;
    document.getElementById('maxRating').value = 10;
    document.getElementById('dateFilter').value = '';
    document.getElementById('sortOrder').value = 'newest';
    document.getElementById('hasImageFilter').checked = false;
    document.getElementById('mergedReviewsFilter').checked = false;
    
    updateRatingRangeDisplay();
    applyAdvancedSearch();
}

function applyAdvancedSearch() {
    const searchTerm = searchInput.value.toLowerCase().trim();
    const genreFilter = document.getElementById('genreFilter').value;
    const minRating = parseInt(document.getElementById('minRating').value);
    const maxRating = parseInt(document.getElementById('maxRating').value);
    const dateFilter = document.getElementById('dateFilter').value;
    const sortOrder = document.getElementById('sortOrder').value;
    const hasImageFilter = document.getElementById('hasImageFilter').checked;
    const mergedReviewsFilter = document.getElementById('mergedReviewsFilter').checked;
    
    // Start with all posts
    filteredPosts = [...allPosts];
    
    // Apply text search
    if (searchTerm) {
        filteredPosts = filteredPosts.filter(post => {
            const titleMatch = post.title.toLowerCase().includes(searchTerm);
            const genreMatch = post.genre && post.genre.toLowerCase().includes(searchTerm);
            const reviewMatch = post.review.toLowerCase().includes(searchTerm);
            const authorMatch = post.authorName.toLowerCase().includes(searchTerm);
            
            return titleMatch || genreMatch || reviewMatch || authorMatch;
        });
    }
    
    // Apply genre filter
    if (genreFilter) {
        filteredPosts = filteredPosts.filter(post => {
            return post.genre && post.genre.toLowerCase().includes(genreFilter.toLowerCase());
        });
    }
    
    // Apply rating range filter
    filteredPosts = filteredPosts.filter(post => {
        const rating = post.rating || 0;
        return rating >= minRating && rating <= maxRating;
    });
    
    // Apply date filter
    if (dateFilter) {
        const now = Date.now();
        const filterDate = getFilterDate(dateFilter, now);
        
        filteredPosts = filteredPosts.filter(post => {
            return post.createdAt >= filterDate;
        });
    }
    
    // Apply image filter
    if (hasImageFilter) {
        filteredPosts = filteredPosts.filter(post => {
            return post.image && post.image.trim() !== '';
        });
    }
    
    // Apply merged reviews filter
    if (mergedReviewsFilter) {
        filteredPosts = filteredPosts.filter(post => {
            return post.mergedReviews && Object.keys(post.mergedReviews).length > 0;
        });
    }
    
    // Apply sorting
    applySorting(sortOrder);
    
    // Display results
    displayPosts();
    
    // Show results count
    showSearchResults();
}

function getFilterDate(dateFilter, now) {
    switch (dateFilter) {
        case 'today':
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            return today.getTime();
        case 'week':
            return now - (7 * 24 * 60 * 60 * 1000);
        case 'month':
            return now - (30 * 24 * 60 * 60 * 1000);
        case 'year':
            return now - (365 * 24 * 60 * 60 * 1000);
        default:
            return 0;
    }
}

function applySorting(sortOrder) {
    switch (sortOrder) {
        case 'newest':
            filteredPosts.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
            break;
        case 'oldest':
            filteredPosts.sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));
            break;
        case 'rating-high':
            filteredPosts.sort((a, b) => (b.rating || 0) - (a.rating || 0));
            break;
        case 'rating-low':
            filteredPosts.sort((a, b) => (a.rating || 0) - (b.rating || 0));
            break;
        case 'most-liked':
            filteredPosts.sort((a, b) => {
                const aLikes = Object.keys(a.likes || {}).length;
                const bLikes = Object.keys(b.likes || {}).length;
                return bLikes - aLikes;
            });
            break;
        case 'most-commented':
            filteredPosts.sort((a, b) => {
                const aComments = Object.keys(a.comments || {}).length;
                const bComments = Object.keys(b.comments || {}).length;
                return bComments - aComments;
            });
            break;
    }
}

function showSearchResults() {
    const totalResults = filteredPosts.length;
    const searchTerm = searchInput.value.trim();
    
    if (searchTerm || !document.getElementById('advancedSearchPanel').classList.contains('d-none')) {
        const resultsText = `Menampilkan ${totalResults} hasil${searchTerm ? ` untuk "${searchTerm}"` : ''}`;
        
        // Create or update results indicator
        let resultsIndicator = document.getElementById('searchResultsIndicator');
        if (!resultsIndicator) {
            resultsIndicator = document.createElement('div');
            resultsIndicator.id = 'searchResultsIndicator';
            resultsIndicator.className = 'alert alert-info d-flex justify-content-between align-items-center';
            postsFeed.parentNode.insertBefore(resultsIndicator, postsFeed);
        }
        
        resultsIndicator.innerHTML = `
            <span><i class="fas fa-search"></i> ${resultsText}</span>
            <button class="btn btn-sm btn-outline-info" onclick="clearAllFilters()">
                <i class="fas fa-times"></i> Clear All
            </button>
        `;
        resultsIndicator.style.display = 'flex';
    } else {
        // Hide results indicator
        const resultsIndicator = document.getElementById('searchResultsIndicator');
        if (resultsIndicator) {
            resultsIndicator.style.display = 'none';
        }
    }
}

function clearAllFilters() {
    // Clear search input
    searchInput.value = '';
    
    // Clear advanced filters
    clearAdvancedFilters();
    
    // Reset to default filter
    filterSelect.value = 'all';
    
    // Hide advanced search panel
    document.getElementById('advancedSearchPanel').classList.add('d-none');
    
    // Apply default filter
    applyCurrentFilter();
    
    // Hide results indicator
    const resultsIndicator = document.getElementById('searchResultsIndicator');
    if (resultsIndicator) {
        resultsIndicator.style.display = 'none';
    }
}

// Dark Mode Functions
function initializeDarkMode() {
    const savedTheme = localStorage.getItem('theme') || 'light';
    applyTheme(savedTheme);
    updateDarkModeButton(savedTheme);
}

function toggleDarkMode() {
    const currentTheme = document.documentElement.getAttribute('data-theme') || 'light';
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    
    applyTheme(newTheme);
    localStorage.setItem('theme', newTheme);
    updateDarkModeButton(newTheme);
    
    showNotification(`${newTheme === 'dark' ? 'Dark' : 'Light'} mode activated!`, 'info');
}

function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
}

function updateDarkModeButton(theme) {
    const button = document.getElementById('darkModeToggle');
    if (button) {
        const icon = button.querySelector('i');
        if (theme === 'dark') {
            icon.className = 'fas fa-sun';
            button.title = 'Switch to Light Mode';
        } else {
            icon.className = 'fas fa-moon';
            button.title = 'Switch to Dark Mode';
        }
    }
}

// Follow System Functions
let followingUsers = new Set();

function loadFollowingData() {
    database.ref(`users/${currentUser.uid}/following`).on('value', (snapshot) => {
        followingUsers.clear();
        const following = snapshot.val();
        if (following) {
            Object.keys(following).forEach(userId => {
                followingUsers.add(userId);
            });
        }
        updateFollowButtons();
    });
}

function updateFollowButtons() {
    // Update all follow buttons on the page
    followingUsers.forEach(userId => {
        const button = document.getElementById(`follow-btn-${userId}`);
        if (button) {
            const icon = button.querySelector('i');
            const span = button.querySelector('span');
            icon.className = 'fas fa-user-check';
            span.textContent = 'Following';
            button.classList.remove('btn-outline-primary');
            button.classList.add('btn-primary');
        }
    });
}

async function toggleFollow(userId, userName) {
    try {
        const isFollowing = followingUsers.has(userId);
        
        if (isFollowing) {
            // Unfollow
            await database.ref(`users/${currentUser.uid}/following/${userId}`).remove();
            await database.ref(`users/${userId}/followers/${currentUser.uid}`).remove();
            
            // Update user stats
            await updateUserFollowStats(currentUser.uid, 'followingCount', -1);
            await updateUserFollowStats(userId, 'followersCount', -1);
            
            showNotification(`Tidak lagi mengikuti ${userName}`, 'info');
        } else {
            // Follow
            const followData = {
                userName: userName,
                timestamp: firebase.database.ServerValue.TIMESTAMP
            };
            
            const followerData = {
                userName: currentUser.displayName || currentUser.email,
                timestamp: firebase.database.ServerValue.TIMESTAMP
            };
            
            await database.ref(`users/${currentUser.uid}/following/${userId}`).set(followData);
            await database.ref(`users/${userId}/followers/${currentUser.uid}`).set(followerData);
            
            // Update user stats
            await updateUserFollowStats(currentUser.uid, 'followingCount', 1);
            await updateUserFollowStats(userId, 'followersCount', 1);
            
            showNotification(`Sekarang mengikuti ${userName}`, 'success');
        }
        
    } catch (error) {
        console.error('Error toggling follow:', error);
        showNotification('Gagal mengubah status follow: ' + error.message, 'danger');
    }
}

async function updateUserFollowStats(userId, statType, increment) {
    try {
        await database.ref(`users/${userId}/${statType}`).transaction((currentValue) => {
            return Math.max(0, (currentValue || 0) + increment);
        });
    } catch (error) {
        console.error('Error updating follow stats:', error);
    }
}

function viewUserProfile(userId) {
    // For now, just show notification. Later can implement user profile modal
    showNotification('Fitur lihat profile user akan segera tersedia!', 'info');
}

// Apply Current Filter with Following Support
function applyCurrentFilter() {
    filteredPosts = [...allPosts];
    
    switch (currentFilter) {
        case 'latest':
            // Already sorted by newest
            break;
        case 'popular':
            filteredPosts.sort((a, b) => {
                const aLikes = Object.keys(a.likes || {}).length;
                const bLikes = Object.keys(b.likes || {}).length;
                return bLikes - aLikes;
            });
            break;
        case 'highest-rated':
            filteredPosts.sort((a, b) => (b.rating || 0) - (a.rating || 0));
            break;
        case 'following':
            // Filter posts from followed users
            filteredPosts = filteredPosts.filter(post => {
                return followingUsers.has(post.authorId) || post.authorId === currentUser.uid;
            });
            break;
    }
    
    displayPosts();
}

// Performance Optimization Functions
let lazyLoadObserver;
let virtualScrollContainer;
let visiblePosts = [];
const POSTS_PER_BATCH = 10;

function initializeLazyLoading() {
    // Intersection Observer for lazy loading images
    lazyLoadObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                const src = img.getAttribute('data-src');
                
                if (src) {
                    // Create a new image to preload
                    const newImg = new Image();
                    newImg.onload = () => {
                        img.src = src;
                        img.classList.remove('lazy-load');
                        img.classList.add('loaded');
                    };
                    newImg.onerror = () => {
                        img.src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="400" height="300"%3E%3Crect width="100%25" height="100%25" fill="%23e9ecef"/%3E%3Ctext x="50%25" y="50%25" text-anchor="middle" dy=".3em" fill="%23666"%3EImage not found%3C/text%3E%3C/svg%3E';
                        img.classList.remove('lazy-load');
                    };
                    newImg.src = src;
                    
                    lazyLoadObserver.unobserve(img);
                }
            }
        });
    }, {
        rootMargin: '50px 0px',
        threshold: 0.1
    });
    
    // Observe existing lazy load images
    observeLazyImages();
}

function observeLazyImages() {
    const lazyImages = document.querySelectorAll('.lazy-load');
    lazyImages.forEach(img => {
        lazyLoadObserver.observe(img);
    });
}

// Enhanced Display Posts with Virtual Scrolling
function displayPosts() {
    if (filteredPosts.length === 0) {
        postsFeed.innerHTML = `
            <div class="text-center py-5">
                <i class="fas fa-film display-1 text-muted"></i>
                <h3 class="mt-3 text-muted">Belum ada post</h3>
                <p class="text-muted">Jadilah yang pertama membuat review anime!</p>
                <button class="btn btn-primary" onclick="showCreatePost()">
                    <i class="fas fa-plus"></i> Buat Post Pertama
                </button>
            </div>
        `;
        return;
    }
    
    // Use virtual scrolling for better performance
    const startIndex = 0;
    const endIndex = Math.min(currentPage * postsPerPage, filteredPosts.length);
    const postsToShow = filteredPosts.slice(startIndex, endIndex);
    
    // Use document fragment for better performance
    const fragment = document.createDocumentFragment();
    
    postsToShow.forEach(post => {
        const postElement = document.createElement('div');
        postElement.innerHTML = createPostHTML(post);
        fragment.appendChild(postElement.firstElementChild);
    });
    
    postsFeed.innerHTML = '';
    postsFeed.appendChild(fragment);
    
    // Observe new lazy load images
    observeLazyImages();
    
    // Show/hide load more button
    const loadMoreBtn = document.getElementById('loadMoreBtn');
    if (endIndex < filteredPosts.length) {
        loadMoreBtn.style.display = 'block';
        
        // Implement infinite scroll
        if (!loadMoreBtn.hasAttribute('data-scroll-listener')) {
            loadMoreBtn.setAttribute('data-scroll-listener', 'true');
            window.addEventListener('scroll', throttle(handleInfiniteScroll, 200));
        }
    } else {
        loadMoreBtn.style.display = 'none';
    }
}

// Infinite Scroll Handler
function handleInfiniteScroll() {
    const loadMoreBtn = document.getElementById('loadMoreBtn');
    if (loadMoreBtn && loadMoreBtn.style.display !== 'none') {
        const rect = loadMoreBtn.getBoundingClientRect();
        const isVisible = rect.top < window.innerHeight && rect.bottom >= 0;
        
        if (isVisible && !loadMoreBtn.classList.contains('loading')) {
            loadMorePosts();
        }
    }
}

// Enhanced Load More Posts
function loadMorePosts() {
    const loadMoreBtn = document.getElementById('loadMoreBtn');
    const spinner = document.getElementById('loadingSpinner');
    
    // Show loading state
    loadMoreBtn.classList.add('loading');
    spinner.classList.remove('d-none');
    loadMoreBtn.disabled = true;
    
    // Simulate loading delay for better UX
    setTimeout(() => {
        currentPage++;
        
        const startIndex = (currentPage - 1) * postsPerPage;
        const endIndex = Math.min(currentPage * postsPerPage, filteredPosts.length);
        const newPosts = filteredPosts.slice(startIndex, endIndex);
        
        // Create fragment for new posts
        const fragment = document.createDocumentFragment();
        
        newPosts.forEach(post => {
            const postElement = document.createElement('div');
            postElement.innerHTML = createPostHTML(post);
            fragment.appendChild(postElement.firstElementChild);
        });
        
        postsFeed.appendChild(fragment);
        
        // Observe new lazy load images
        observeLazyImages();
        
        // Hide loading state
        loadMoreBtn.classList.remove('loading');
        spinner.classList.add('d-none');
        loadMoreBtn.disabled = false;
        
        // Hide button if no more posts
        if (endIndex >= filteredPosts.length) {
            loadMoreBtn.style.display = 'none';
        }
        
    }, 500); // Small delay for better UX
}

// Image Compression for Upload
async function compressImage(file, maxWidth = 800, quality = 0.8) {
    return new Promise((resolve) => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        const img = new Image();
        
        img.onload = () => {
            // Calculate new dimensions
            let { width, height } = img;
            
            if (width > maxWidth) {
                height = (height * maxWidth) / width;
                width = maxWidth;
            }
            
            canvas.width = width;
            canvas.height = height;
            
            // Draw and compress
            ctx.drawImage(img, 0, 0, width, height);
            canvas.toBlob(resolve, 'image/jpeg', quality);
        };
        
        img.src = URL.createObjectURL(file);
    });
}

// Enhanced Convert to Base64 with Compression
async function convertToBase64(file) {
    // Compress image first
    const compressedFile = await compressImage(file);
    
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(compressedFile);
        reader.onload = () => resolve(reader.result);
        reader.onerror = error => reject(error);
    });
}

// Throttle function for performance
function throttle(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Memory Management
function cleanupObservers() {
    if (lazyLoadObserver) {
        lazyLoadObserver.disconnect();
    }
}

// Cleanup on page unload
window.addEventListener('beforeunload', cleanupObservers);

// Logout Function
function logout() {
    cleanupObservers();
    auth.signOut().then(() => {
        showNotification('Logout berhasil!', 'success');
        setTimeout(() => {
            window.location.href = 'welcome.html';
        }, 1000);
    });
} 