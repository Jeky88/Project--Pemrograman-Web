// Konfigurasi Firebase
const firebaseConfig = {
    apiKey: "AIzaSyDrLa3Lu-CSO8az4XO42ixnCBU1toVFdsw",
    authDomain: "review-anime.firebaseapp.com",
    databaseURL: "https://review-anime-default-rtdb.asia-southeast1.firebasedatabase.app/",
    projectId: "review-anime",
    storageBucket: "review-anime.firebasestorage.app",
    messagingSenderId: "896892641219",
    appId: "1:896892641219:web:22c9cea128e5adf88d6776"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const database = firebase.database();

// Global variables
let currentUser = null;
let allReviews = [];

// DOM Elements
const welcomePage = document.getElementById('welcome-page');
const dashboard = document.getElementById('dashboard');
const loginModal = new bootstrap.Modal(document.getElementById('loginModal'));
const registerModal = new bootstrap.Modal(document.getElementById('registerModal'));

// Authentication State Observer
auth.onAuthStateChanged((user) => {
    if (user) {
        currentUser = user;
        showDashboard();
        loadReviews();
    } else {
        currentUser = null;
        showWelcomePage();
    }
});

// Show/Hide Functions
function showWelcomePage() {
    welcomePage.classList.remove('d-none');
    dashboard.classList.add('d-none');
    
    // Update navigation
    document.getElementById('login-nav').classList.remove('d-none');
    document.getElementById('register-nav').classList.remove('d-none');
    document.getElementById('dashboard-nav').classList.add('d-none');
    document.getElementById('logout-nav').classList.add('d-none');
}

function showDashboard() {
    welcomePage.classList.add('d-none');
    dashboard.classList.remove('d-none');
    
    // Update navigation
    document.getElementById('login-nav').classList.add('d-none');
    document.getElementById('register-nav').classList.add('d-none');
    document.getElementById('dashboard-nav').classList.remove('d-none');
    document.getElementById('logout-nav').classList.remove('d-none');
}

function showLogin() {
    loginModal.show();
}

function showRegister() {
    registerModal.show();
}

// Authentication Functions
document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    
    try {
        await auth.signInWithEmailAndPassword(email, password);
        loginModal.hide();
        showNotification('Login berhasil!', 'success');
    } catch (error) {
        showNotification('Login gagal: ' + error.message, 'danger');
    }
});

document.getElementById('registerForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const name = document.getElementById('registerName').value;
    const email = document.getElementById('registerEmail').value;
    const password = document.getElementById('registerPassword').value;
    const confirmPassword = document.getElementById('registerConfirmPassword').value;
    
    if (password !== confirmPassword) {
        showNotification('Password tidak cocok!', 'danger');
        return;
    }
    
    if (password.length < 6) {
        showNotification('Password harus minimal 6 karakter!', 'danger');
        return;
    }
    
    try {
        const userCredential = await auth.createUserWithEmailAndPassword(email, password);
        
        // Update user profile
        await userCredential.user.updateProfile({
            displayName: name
        });
        
        // Save user profile to database (only if database rules allow)
        try {
            await database.ref('users/' + userCredential.user.uid).set({
                name: name,
                email: email,
                createdAt: firebase.database.ServerValue.TIMESTAMP
            });
        } catch (dbError) {
            console.warn('Could not save user profile to database:', dbError.message);
            // Continue anyway since auth was successful
        }
        
        registerModal.hide();
        showNotification('Registrasi berhasil!', 'success');
    } catch (error) {
        console.error('Registration error:', error);
        let errorMessage = 'Registrasi gagal: ';
        
        switch (error.code) {
            case 'auth/email-already-in-use':
                errorMessage += 'Email sudah digunakan';
                break;
            case 'auth/invalid-email':
                errorMessage += 'Format email tidak valid';
                break;
            case 'auth/weak-password':
                errorMessage += 'Password terlalu lemah';
                break;
            case 'auth/operation-not-allowed':
                errorMessage += 'Email/Password authentication belum diaktifkan di Firebase Console';
                break;
            default:
                errorMessage += error.message;
        }
        
        showNotification(errorMessage, 'danger');
    }
});

function logout() {
    auth.signOut().then(() => {
        showNotification('Logout berhasil!', 'success');
    });
}

// Review Functions
document.getElementById('addReviewForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    if (!currentUser) {
        showNotification('Silakan login terlebih dahulu!', 'warning');
        return;
    }
    
    const title = document.getElementById('animeTitle').value;
    const genre = document.getElementById('animeGenre').value;
    const rating = parseInt(document.getElementById('animeRating').value);
    const review = document.getElementById('animeReview').value;
    const imageFile = document.getElementById('animeImage').files[0];
    
    let imageBase64 = '';
    if (imageFile) {
        try {
            imageBase64 = await convertToBase64(imageFile);
        } catch (error) {
            showNotification('Gagal mengupload gambar: ' + error.message, 'danger');
            return;
        }
    }
    
    try {
        const reviewData = {
            title: title,
            genre: genre,
            rating: rating,
            review: review,
            image: imageBase64,
            authorId: currentUser.uid,
            authorName: currentUser.displayName || currentUser.email,
            createdAt: firebase.database.ServerValue.TIMESTAMP,
            comments: {}
        };
        
        await database.ref('reviews').push(reviewData);
        
        // Reset form
        document.getElementById('addReviewForm').reset();
        showNotification('Review berhasil ditambahkan!', 'success');
        
    } catch (error) {
        console.error('Add review error:', error);
        let errorMessage = 'Gagal menambahkan review: ';
        
        if (error.code === 'PERMISSION_DENIED') {
            errorMessage += 'Database rules tidak mengizinkan operasi ini. Pastikan Realtime Database sudah disetup dengan benar.';
        } else {
            errorMessage += error.message;
        }
        
        showNotification(errorMessage, 'danger');
    }
});

// Convert image to base64
function convertToBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result);
        reader.onerror = error => reject(error);
    });
}

// Load Reviews
function loadReviews() {
    const reviewsList = document.getElementById('reviewsList');
    reviewsList.innerHTML = '<div class="loading"><div class="spinner"></div></div>';
    
    database.ref('reviews').orderByChild('createdAt').on('value', (snapshot) => {
        allReviews = [];
        const reviews = snapshot.val();
        
        if (reviews) {
            Object.keys(reviews).forEach(key => {
                allReviews.push({
                    id: key,
                    ...reviews[key]
                });
            });
            
            // Sort by newest first
            allReviews.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        }
        
        displayReviews(allReviews);
    });
}

// Display Reviews
function displayReviews(reviews) {
    const reviewsList = document.getElementById('reviewsList');
    
    if (reviews.length === 0) {
        reviewsList.innerHTML = `
            <div class="text-center py-5">
                <i class="fas fa-film display-1 text-muted"></i>
                <h3 class="mt-3 text-muted">Belum ada review</h3>
                <p class="text-muted">Jadilah yang pertama menambahkan review anime!</p>
            </div>
        `;
        return;
    }
    
    reviewsList.innerHTML = reviews.map(review => `
        <div class="card review-card fade-in">
            <div class="card-body">
                <div class="review-header">
                    <h5 class="review-title">${review.title}</h5>
                    <div class="review-rating">
                        ${generateStars(review.rating)}
                        <span class="ms-2"><strong>${review.rating}/10</strong></span>
                    </div>
                </div>
                
                <div class="review-meta">
                    <i class="fas fa-user"></i> ${review.authorName} • 
                    <i class="fas fa-clock"></i> ${formatDate(review.createdAt)}
                </div>
                
                ${review.genre ? `
                    <div class="review-tags">
                        ${review.genre.split(',').map(g => `<span class="tag">${g.trim()}</span>`).join('')}
                    </div>
                ` : ''}
                
                ${review.image ? `
                    <img src="${review.image}" alt="${review.title}" class="review-image">
                ` : ''}
                
                <div class="review-content">
                    ${review.review}
                </div>
                
                <div class="comments-section">
                    <h6><i class="fas fa-comments"></i> Komentar</h6>
                    <div id="comments-${review.id}">
                        ${displayComments(review.comments)}
                    </div>
                    
                    ${currentUser ? `
                        <div class="comment-form">
                            <div class="input-group">
                                <textarea class="form-control comment-input" 
                                         placeholder="Tulis komentar..." 
                                         rows="2" 
                                         id="comment-${review.id}"></textarea>
                                <button class="btn btn-primary" 
                                        onclick="addComment('${review.id}')">
                                    <i class="fas fa-paper-plane"></i>
                                </button>
                            </div>
                        </div>
                    ` : ''}
                </div>
            </div>
        </div>
    `).join('');
}

// Generate star rating
function generateStars(rating) {
    const fullStars = Math.floor(rating);
    const halfStar = rating % 1 !== 0;
    const emptyStars = 10 - Math.ceil(rating);
    
    let stars = '';
    
    for (let i = 0; i < fullStars; i++) {
        stars += '<i class="fas fa-star star-rating"></i>';
    }
    
    if (halfStar) {
        stars += '<i class="fas fa-star-half-alt star-rating"></i>';
    }
    
    for (let i = 0; i < emptyStars; i++) {
        stars += '<i class="far fa-star star-rating"></i>';
    }
    
    return stars;
}

// Format date
function formatDate(timestamp) {
    if (!timestamp) return 'Baru saja';
    
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now - date;
    
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    
    if (minutes < 1) return 'Baru saja';
    if (minutes < 60) return `${minutes} menit yang lalu`;
    if (hours < 24) return `${hours} jam yang lalu`;
    if (days < 7) return `${days} hari yang lalu`;
    
    return date.toLocaleDateString('id-ID');
}

// Display Comments
function displayComments(comments) {
    if (!comments) return '<p class="text-muted">Belum ada komentar</p>';
    
    const commentsArray = Object.keys(comments).map(key => ({
        id: key,
        ...comments[key]
    }));
    
    // Sort by newest first
    commentsArray.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    
    return commentsArray.map(comment => `
        <div class="comment">
            <div class="comment-author">${comment.authorName}</div>
            <div class="comment-text">${comment.text}</div>
            <small class="text-muted">${formatDate(comment.createdAt)}</small>
        </div>
    `).join('');
}

// Add Comment
async function addComment(reviewId) {
    if (!currentUser) {
        showNotification('Silakan login terlebih dahulu!', 'warning');
        return;
    }
    
    const commentInput = document.getElementById(`comment-${reviewId}`);
    const commentText = commentInput.value.trim();
    
    if (!commentText) {
        showNotification('Komentar tidak boleh kosong!', 'warning');
        return;
    }
    
    try {
        const commentData = {
            text: commentText,
            authorId: currentUser.uid,
            authorName: currentUser.displayName || currentUser.email,
            createdAt: firebase.database.ServerValue.TIMESTAMP
        };
        
        await database.ref(`reviews/${reviewId}/comments`).push(commentData);
        commentInput.value = '';
        showNotification('Komentar berhasil ditambahkan!', 'success');
        
    } catch (error) {
        showNotification('Gagal menambahkan komentar: ' + error.message, 'danger');
    }
}

// Search Reviews
function searchReviews() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase().trim();
    
    if (!searchTerm) {
        displayReviews(allReviews);
        return;
    }
    
    const filteredReviews = allReviews.filter(review => {
        const titleMatch = review.title.toLowerCase().includes(searchTerm);
        const genreMatch = review.genre && review.genre.toLowerCase().includes(searchTerm);
        const reviewMatch = review.review.toLowerCase().includes(searchTerm);
        const authorMatch = review.authorName.toLowerCase().includes(searchTerm);
        
        // Search in comments
        let commentMatch = false;
        if (review.comments) {
            Object.values(review.comments).forEach(comment => {
                if (comment.text.toLowerCase().includes(searchTerm)) {
                    commentMatch = true;
                }
            });
        }
        
        return titleMatch || genreMatch || reviewMatch || authorMatch || commentMatch;
    });
    
    displayReviews(filteredReviews);
    
    if (filteredReviews.length === 0) {
        document.getElementById('reviewsList').innerHTML = `
            <div class="text-center py-5">
                <i class="fas fa-search display-1 text-muted"></i>
                <h3 class="mt-3 text-muted">Tidak ditemukan</h3>
                <p class="text-muted">Tidak ada review yang cocok dengan pencarian "${searchTerm}"</p>
            </div>
        `;
    }
}

// Search on Enter key
document.getElementById('searchInput').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        searchReviews();
    }
});

// Show Notification
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
    notification.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.parentNode.removeChild(notification);
        }
    }, 5000);
}

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
    // Check if user is already logged in
    const user = auth.currentUser;
    if (user) {
        currentUser = user;
        showDashboard();
        loadReviews();
    } else {
        showWelcomePage();
    }
});

// Utility Functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Real-time search with debounce
document.getElementById('searchInput').addEventListener('input', 
    debounce(() => {
        searchReviews();
    }, 300)
);

// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const href = this.getAttribute('href');
        if (href && href !== '#') {
            const target = document.querySelector(href);
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        }
    });
});

// Handle image preview
document.getElementById('animeImage').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            // You can add image preview functionality here
            console.log('Image loaded:', e.target.result.substring(0, 50) + '...');
        };
        reader.readAsDataURL(file);
    }
});

// Error handling for Firebase operations
window.addEventListener('unhandledrejection', (event) => {
    console.error('Unhandled promise rejection:', event.reason);
    showNotification('Terjadi kesalahan: ' + event.reason.message, 'danger');
});

// Service Worker Registration (for PWA support) - Disabled for now
// Uncomment and create sw.js file if you want PWA support
/*
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
            .then((registration) => {
                console.log('SW registered: ', registration);
            })
            .catch((registrationError) => {
                console.log('SW registration failed: ', registrationError);
            });
    });
}
*/ 