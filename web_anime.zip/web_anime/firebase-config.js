// Firebase Configuration
// Ganti dengan konfigurasi Firebase Anda sendiri
// Dapatkan konfigurasi ini dari Firebase Console > Project Settings > General > Your apps

const firebaseConfig = {
    apiKey: "AIzaSyDrLa3Lu-CSO8az4XO42ixnCBU1toVFdsw",
    authDomain: "review-anime.firebaseapp.com",
    databaseURL: "https://review-anime-default-rtdb.asia-southeast1.firebasedatabase.app/",
    projectId: "review-anime",
    storageBucket: "review-anime.firebasestorage.app",
    messagingSenderId: "896892641219",
    appId: "1:896892641219:web:22c9cea128e5adf88d6776"
};

// Panduan Setup Firebase:
// 1. Buat project baru di https://console.firebase.google.com/
// 2. Aktifkan Authentication > Sign-in method > Email/Password
// 3. Aktifkan Realtime Database > Create database > Start in test mode
// 4. Ganti konfigurasi di atas dengan konfigurasi project Anda
// 5. Untuk production, atur rules database dengan lebih ketat

// Contoh Database Rules untuk production:
/*
{
  "rules": {
    "users": {
      "$uid": {
        ".read": "$uid === auth.uid",
        ".write": "$uid === auth.uid"
      }
    },
    "reviews": {
      ".read": "auth != null",
      ".write": "auth != null",
      "$reviewId": {
        ".validate": "newData.hasChildren(['title', 'rating', 'review', 'authorId'])",
        "authorId": {
          ".validate": "newData.val() === auth.uid"
        },
        "comments": {
          "$commentId": {
            ".validate": "newData.hasChildren(['text', 'authorId'])",
            "authorId": {
              ".validate": "newData.val() === auth.uid"
            }
          }
        }
      }
    }
  }
}
*/ 