// Demo data untuk testing AnimeReview
// Jalankan fungsi ini setelah setup Firebase untuk menambah data contoh

function addDemoData() {
    // Pastikan user sudah login
    if (!currentUser) {
        console.log('Please login first to add demo data');
        return;
    }
    
    const demoReviews = [
        {
            title: "Attack on Titan",
            genre: "Action, Drama, Fantasy",
            rating: 9,
            review: "Anime yang luar biasa dengan plot twist yang tidak terduga. Cerita yang kompleks dan karakter yang berkembang dengan baik. Animasi yang menakjubkan dan soundtrack yang epic. Sangat direkomendasikan untuk pecinta anime action!",
            image: "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMzAwIiBoZWlnaHQ9IjIwMCIgZmlsbD0iIzMzNzNkYyIvPjx0ZXh0IHg9IjE1MCIgeT0iMTAwIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTgiIGZpbGw9IndoaXRlIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSI+QXR0YWNrIG9uIFRpdGFuPC90ZXh0Pjwvc3ZnPg==",
            authorId: currentUser.uid,
            authorName: currentUser.displayName || currentUser.email,
            createdAt: Date.now() - 86400000, // 1 day ago
            comments: {
                comment1: {
                    text: "Setuju banget! Anime terbaik yang pernah saya tonton.",
                    authorId: "demo-user-1",
                    authorName: "Anime Lover",
                    createdAt: Date.now() - 43200000 // 12 hours ago
                },
                comment2: {
                    text: "Season terakhir benar-benar mind-blowing!",
                    authorId: "demo-user-2",
                    authorName: "Otaku Master",
                    createdAt: Date.now() - 21600000 // 6 hours ago
                }
            }
        },
        {
            title: "Demon Slayer",
            genre: "Action, Supernatural, Historical",
            rating: 8,
            review: "Animasi yang sangat indah dengan fight scene yang memukau. Karakter Tanjiro yang sangat likeable dan cerita yang touching. Ufotable benar-benar menunjukkan kualitas animasi terbaik mereka.",
            image: "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMzAwIiBoZWlnaHQ9IjIwMCIgZmlsbD0iI2RjMzU0NSIvPjx0ZXh0IHg9IjE1MCIgeT0iMTAwIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTgiIGZpbGw9IndoaXRlIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSI+RGVtb24gU2xheWVyPC90ZXh0Pjwvc3ZnPg==",
            authorId: currentUser.uid,
            authorName: currentUser.displayName || currentUser.email,
            createdAt: Date.now() - 172800000, // 2 days ago
            comments: {
                comment1: {
                    text: "Animasi Ufotable memang tidak pernah mengecewakan!",
                    authorId: "demo-user-3",
                    authorName: "Animation Fan",
                    createdAt: Date.now() - 86400000 // 1 day ago
                }
            }
        },
        {
            title: "Your Name",
            genre: "Romance, Drama, Supernatural",
            rating: 10,
            review: "Masterpiece dari Makoto Shinkai. Cerita yang menyentuh hati dengan visual yang breathtaking. Soundtrack yang sempurna melengkapi pengalaman menonton. Film yang wajib ditonton oleh semua orang!",
            image: "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMzAwIiBoZWlnaHQ9IjIwMCIgZmlsbD0iIzI4YTc0NSIvPjx0ZXh0IHg9IjE1MCIgeT0iMTAwIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTgiIGZpbGw9IndoaXRlIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSI+WW91ciBOYW1lPC90ZXh0Pjwvc3ZnPg==",
            authorId: currentUser.uid,
            authorName: currentUser.displayName || currentUser.email,
            createdAt: Date.now() - 259200000, // 3 days ago
            comments: {
                comment1: {
                    text: "Saya sampai menangis nonton ini T_T",
                    authorId: "demo-user-4",
                    authorName: "Movie Critic",
                    createdAt: Date.now() - 172800000 // 2 days ago
                },
                comment2: {
                    text: "Makoto Shinkai memang raja dalam hal visual!",
                    authorId: "demo-user-5",
                    authorName: "Visual Artist",
                    createdAt: Date.now() - 129600000 // 1.5 days ago
                }
            }
        },
        {
            title: "Jujutsu Kaisen",
            genre: "Action, School, Supernatural",
            rating: 9,
            review: "Anime action terbaru yang sangat promising. Sistem magic yang unik dan karakter yang menarik. MAPPA berhasil mengadaptasi manga dengan sangat baik. Gojo Satoru adalah karakter terkuat dan terkeren!",
            image: "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMzAwIiBoZWlnaHQ9IjIwMCIgZmlsbD0iIzY2N2VlYSIvPjx0ZXh0IHg9IjE1MCIgeT0iMTAwIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTgiIGZpbGw9IndoaXRlIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSI+SnVqdXRzdSBLYWlzZW48L3RleHQ+PC9zdmc+",
            authorId: currentUser.uid,
            authorName: currentUser.displayName || currentUser.email,
            createdAt: Date.now() - 345600000, // 4 days ago
            comments: {
                comment1: {
                    text: "Gojo sensei adalah GOAT! 🔥",
                    authorId: "demo-user-6",
                    authorName: "JJK Fan",
                    createdAt: Date.now() - 259200000 // 3 days ago
                }
            }
        },
        {
            title: "Spirited Away",
            genre: "Adventure, Family, Fantasy",
            rating: 10,
            review: "Karya masterpiece Studio Ghibli yang tak lekang oleh waktu. Cerita yang magical dengan pesan moral yang mendalam. Animasi hand-drawn yang luar biasa indah. Film yang cocok untuk semua umur dan selalu menyentuh hati setiap kali ditonton.",
            image: "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMzAwIiBoZWlnaHQ9IjIwMCIgZmlsbD0iIzc2NGJhMiIvPjx0ZXh0IHg9IjE1MCIgeT0iMTAwIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTgiIGZpbGw9IndoaXRlIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSI+U3Bpcml0ZWQgQXdheTwvdGV4dD48L3N2Zz4=",
            authorId: currentUser.uid,
            authorName: currentUser.displayName || currentUser.email,
            createdAt: Date.now() - 432000000, // 5 days ago
            comments: {
                comment1: {
                    text: "Studio Ghibli tidak pernah gagal membuat saya terpukau!",
                    authorId: "demo-user-7",
                    authorName: "Ghibli Lover",
                    createdAt: Date.now() - 345600000 // 4 days ago
                },
                comment2: {
                    text: "Film yang selalu bikin nostalgia masa kecil 🥺",
                    authorId: "demo-user-8",
                    authorName: "Nostalgic Viewer",
                    createdAt: Date.now() - 302400000 // 3.5 days ago
                }
            }
        }
    ];
    
    // Add demo reviews to Firebase
    demoReviews.forEach(async (review, index) => {
        try {
            await database.ref('reviews').push(review);
            console.log(`Demo review ${index + 1} added: ${review.title}`);
        } catch (error) {
            console.error(`Error adding demo review ${index + 1}:`, error);
        }
    });
    
    console.log('Demo data added successfully!');
    showNotification('Demo data berhasil ditambahkan!', 'success');
}

// Fungsi untuk menghapus semua data demo
function clearDemoData() {
    if (!currentUser) {
        console.log('Please login first to clear demo data');
        return;
    }
    
    if (confirm('Apakah Anda yakin ingin menghapus semua data demo?')) {
        database.ref('reviews').once('value', (snapshot) => {
            const reviews = snapshot.val();
            if (reviews) {
                Object.keys(reviews).forEach(key => {
                    if (reviews[key].authorId === currentUser.uid) {
                        database.ref(`reviews/${key}`).remove();
                    }
                });
                console.log('Demo data cleared successfully!');
                showNotification('Demo data berhasil dihapus!', 'success');
            }
        });
    }
}

// Fungsi untuk menambah user demo
function addDemoUsers() {
    const demoUsers = [
        {
            uid: 'demo-user-1',
            name: 'Anime Lover',
            email: 'anime.lover@demo.com'
        },
        {
            uid: 'demo-user-2',
            name: 'Otaku Master',
            email: 'otaku.master@demo.com'
        },
        {
            uid: 'demo-user-3',
            name: 'Animation Fan',
            email: 'animation.fan@demo.com'
        },
        {
            uid: 'demo-user-4',
            name: 'Movie Critic',
            email: 'movie.critic@demo.com'
        },
        {
            uid: 'demo-user-5',
            name: 'Visual Artist',
            email: 'visual.artist@demo.com'
        },
        {
            uid: 'demo-user-6',
            name: 'JJK Fan',
            email: 'jjk.fan@demo.com'
        },
        {
            uid: 'demo-user-7',
            name: 'Ghibli Lover',
            email: 'ghibli.lover@demo.com'
        },
        {
            uid: 'demo-user-8',
            name: 'Nostalgic Viewer',
            email: 'nostalgic.viewer@demo.com'
        }
    ];
    
    demoUsers.forEach(user => {
        database.ref(`users/${user.uid}`).set({
            name: user.name,
            email: user.email,
            createdAt: Date.now() - Math.random() * 86400000 * 30 // Random date in last 30 days
        });
    });
    
    console.log('Demo users added successfully!');
}

// Fungsi untuk testing search
function testSearch() {
    const searchTerms = ['attack', 'demon', 'gojo', 'ghibli', 'action'];
    const randomTerm = searchTerms[Math.floor(Math.random() * searchTerms.length)];
    
    document.getElementById('searchInput').value = randomTerm;
    searchReviews();
    
    console.log(`Testing search with term: ${randomTerm}`);
}

// Export functions untuk digunakan di console
window.addDemoData = addDemoData;
window.clearDemoData = clearDemoData;
window.addDemoUsers = addDemoUsers;
window.testSearch = testSearch;

// Instruksi penggunaan
console.log(`
🎌 AnimeReview Demo Functions:
- addDemoData(): Menambah data review demo
- clearDemoData(): Menghapus semua data demo
- addDemoUsers(): Menambah user demo
- testSearch(): Test fungsi pencarian

Pastikan Anda sudah login sebelum menjalankan fungsi demo!
`);

// Demo Data untuk Testing AnimeReview
const demoData = {
    // Sample anime data
    animeList: [
        {
            title: "Attack on Titan",
            genre: "Action, Drama, Fantasy",
            rating: 9.2,
            image: "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAwIiBoZWlnaHQ9IjQwMCIgdmlld0JveD0iMCAwIDMwMCA0MDAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSIzMDAiIGhlaWdodD0iNDAwIiBmaWxsPSIjRkY2B0MzIi8+Cjx0ZXh0IHg9IjE1MCIgeT0iMjAwIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmaWxsPSJ3aGl0ZSIgZm9udC1zaXplPSIyMCIgZm9udC1mYW1pbHk9IkFyaWFsIj5BdHRhY2sgb24gVGl0YW48L3RleHQ+Cjwvc3ZnPg==",
            description: "Manusia melawan titan raksasa dalam perjuangan untuk bertahan hidup."
        },
        {
            title: "Demon Slayer",
            genre: "Action, Supernatural, Historical",
            rating: 8.9,
            image: "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAwIiBoZWlnaHQ9IjQwMCIgdmlld0JveD0iMCAwIDMwMCA0MDAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSIzMDAiIGhlaWdodD0iNDAwIiBmaWxsPSIjRkY0QjRCIi8+Cjx0ZXh0IHg9IjE1MCIgeT0iMjAwIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmaWxsPSJ3aGl0ZSIgZm9udC1zaXplPSIyMCIgZm9udC1mYW1pbHk9IkFyaWFsIj5EZW1vbiBTbGF5ZXI8L3RleHQ+Cjwvc3ZnPg==",
            description: "Tanjiro berjuang melawan iblis untuk menyelamatkan adiknya."
        },
        {
            title: "One Piece",
            genre: "Adventure, Comedy, Drama",
            rating: 9.0,
            image: "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAwIiBoZWlnaHQ9IjQwMCIgdmlld0JveD0iMCAwIDMwMCA0MDAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSIzMDAiIGhlaWdodD0iNDAwIiBmaWxsPSIjNDI4NUY0Ii8+Cjx0ZXh0IHg9IjE1MCIgeT0iMjAwIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmaWxsPSJ3aGl0ZSIgZm9udC1zaXplPSIyMCIgZm9udC1mYW1pbHk9IkFyaWFsIj5PbmUgUGllY2U8L3RleHQ+Cjwvc3ZnPg==",
            description: "Luffy dan kru bajak laut mencari harta karun legendaris One Piece."
        },
        {
            title: "Naruto",
            genre: "Action, Adventure, Martial Arts",
            rating: 8.7,
            image: "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAwIiBoZWlnaHQ9IjQwMCIgdmlld0JveD0iMCAwIDMwMCA0MDAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSIzMDAiIGhlaWdodD0iNDAwIiBmaWxsPSIjRkY5ODAwIi8+Cjx0ZXh0IHg9IjE1MCIgeT0iMjAwIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmaWxsPSJ3aGl0ZSIgZm9udC1zaXplPSIyMCIgZm9udC1mYW1pbHk9IkFyaWFsIj5OYXJ1dG88L3RleHQ+Cjwvc3ZnPg==",
            description: "Ninja muda berjuang untuk menjadi Hokage dan melindungi desanya."
        },
        {
            title: "My Hero Academia",
            genre: "Action, School, Superhero",
            rating: 8.5,
            image: "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAwIiBoZWlnaHQ9IjQwMCIgdmlld0JveD0iMCAwIDMwMCA0MDAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSIzMDAiIGhlaWdodD0iNDAwIiBmaWxsPSIjMDBEQzgyIi8+Cjx0ZXh0IHg9IjE1MCIgeT0iMjAwIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmaWxsPSJ3aGl0ZSIgZm9udC1zaXplPSIxOCIgZm9udC1mYW1pbHk9IkFyaWFsIj5NeSBIZXJvIEFjYWRlbWlhPC90ZXh0Pgo8L3N2Zz4=",
            description: "Deku belajar menjadi superhero di dunia di mana hampir semua orang memiliki kekuatan super."
        }
    ],

    // Sample reviews
    sampleReviews: [
        {
            title: "Attack on Titan",
            genre: "Action, Drama, Fantasy",
            rating: 9,
            review: "Anime yang benar-benar luar biasa! Ceritanya sangat kompleks dan tidak terduga. Setiap episode membuat saya penasaran dengan kelanjutannya. Animasinya juga sangat bagus, terutama saat adegan action melawan titan. Sangat direkomendasikan untuk fans anime action dan drama!",
            author: "AnimeReviewer123",
            timestamp: Date.now() - 86400000, // 1 day ago
            likes: 15,
            comments: 8
        },
        {
            title: "Demon Slayer",
            genre: "Action, Supernatural",
            rating: 8,
            review: "Animasi yang sangat indah, terutama efek visual saat pertarungan. Cerita tentang persaudaraan yang menyentuh hati. Tanjiro adalah karakter utama yang sangat likeable. Musik latar juga sangat epic. Wajib ditonton!",
            author: "OtakuMaster",
            timestamp: Date.now() - 172800000, // 2 days ago
            likes: 23,
            comments: 12
        },
        {
            title: "One Piece",
            genre: "Adventure, Comedy",
            rating: 10,
            review: "Masterpiece sejati! Sudah mengikuti dari episode 1 dan tidak pernah bosan. Worldbuilding yang luar biasa, karakter-karakter yang memorable, dan cerita yang selalu mengejutkan. Luffy adalah karakter protagonis terbaik yang pernah ada!",
            author: "PirateKing",
            timestamp: Date.now() - 259200000, // 3 days ago
            likes: 45,
            comments: 20
        }
    ],

    // Sample users
    sampleUsers: [
        {
            name: "AnimeReviewer123",
            email: "reviewer@example.com",
            bio: "Pecinta anime sejak 2010. Suka genre action dan drama.",
            postCount: 25,
            likeCount: 150,
            commentCount: 80,
            joinDate: "2023-01-15"
        },
        {
            name: "OtakuMaster",
            email: "otaku@example.com",
            bio: "Otaku sejati yang sudah menonton 500+ anime.",
            postCount: 40,
            likeCount: 300,
            commentCount: 120,
            joinDate: "2022-08-20"
        },
        {
            name: "PirateKing",
            email: "onepiece@example.com",
            bio: "One Piece adalah hidup saya!",
            postCount: 15,
            likeCount: 200,
            commentCount: 60,
            joinDate: "2023-03-10"
        }
    ],

    // Sample comments
    sampleComments: [
        {
            text: "Setuju banget! Anime ini benar-benar masterpiece!",
            author: "AnimeFan01",
            timestamp: Date.now() - 43200000 // 12 hours ago
        },
        {
            text: "Sudah nonton berkali-kali tapi masih seru!",
            author: "ReWatcher",
            timestamp: Date.now() - 86400000 // 1 day ago
        },
        {
            text: "Kapan season selanjutnya keluar ya?",
            author: "Impatient",
            timestamp: Date.now() - 21600000 // 6 hours ago
        }
    ],

    // Trending anime data
    trendingAnime: [
        { title: "Attack on Titan", rating: 9.2, reviews: 1250, likes: 3500 },
        { title: "Demon Slayer", rating: 8.9, reviews: 980, likes: 2800 },
        { title: "One Piece", rating: 9.0, reviews: 2100, likes: 4200 },
        { title: "Jujutsu Kaisen", rating: 8.8, reviews: 750, likes: 2200 },
        { title: "Spy x Family", rating: 8.7, reviews: 650, likes: 1900 }
    ],

    // Top reviewers
    topReviewers: [
        { name: "PirateKing", posts: 40, likes: 300 },
        { name: "OtakuMaster", posts: 35, likes: 280 },
        { name: "AnimeReviewer123", posts: 25, likes: 150 },
        { name: "AnimeCritic", posts: 20, likes: 120 },
        { name: "MangaReader", posts: 18, likes: 95 }
    ],

    // Recent activity
    recentActivity: [
        { type: "like", user: "AnimeFan01", target: "Attack on Titan", time: Date.now() - 1800000 },
        { type: "comment", user: "ReWatcher", target: "Demon Slayer", time: Date.now() - 3600000 },
        { type: "like", user: "NewUser", target: "One Piece", time: Date.now() - 5400000 },
        { type: "comment", user: "OtakuMaster", target: "Naruto", time: Date.now() - 7200000 }
    ]
};

// Function to load demo data into Firebase (for testing)
function loadDemoData() {
    if (typeof database === 'undefined') {
        console.log('Firebase not initialized. Demo data not loaded.');
        return;
    }

    // Load sample posts
    demoData.sampleReviews.forEach((review, index) => {
        const postData = {
            title: review.title,
            genre: review.genre,
            rating: review.rating,
            review: review.review,
            authorId: `demo_user_${index}`,
            authorName: review.author,
            createdAt: review.timestamp,
            likes: {},
            comments: {},
            shares: 0,
            allowMerge: true,
            image: demoData.animeList.find(anime => anime.title === review.title)?.image || ''
        };

        // Add some demo likes
        for (let i = 0; i < review.likes; i++) {
            postData.likes[`demo_user_like_${i}`] = {
                timestamp: review.timestamp + (i * 3600000),
                userName: `User${i}`
            };
        }

        // Add some demo comments
        demoData.sampleComments.slice(0, review.comments).forEach((comment, commentIndex) => {
            postData.comments[`demo_comment_${commentIndex}`] = {
                text: comment.text,
                authorId: `demo_user_comment_${commentIndex}`,
                authorName: comment.author,
                createdAt: comment.timestamp
            };
        });

        database.ref('posts').push(postData);
    });

    // Load sample users
    demoData.sampleUsers.forEach((user, index) => {
        const userData = {
            name: user.name,
            email: user.email,
            bio: user.bio,
            postCount: user.postCount,
            likeCount: user.likeCount,
            commentCount: user.commentCount,
            joinDate: user.joinDate
        };

        database.ref(`users/demo_user_${index}`).set(userData);
    });

    console.log('Demo data loaded successfully!');
}

// Auto-load demo data when script is loaded (only in development)
if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
    // Wait for Firebase to initialize
    setTimeout(() => {
        if (typeof database !== 'undefined') {
            // Check if demo data already exists
            database.ref('posts').once('value', (snapshot) => {
                if (!snapshot.exists()) {
                    console.log('Loading demo data for development...');
                    loadDemoData();
                }
            });
        }
    }, 2000);
}

// Export for manual loading
if (typeof module !== 'undefined' && module.exports) {
    module.exports = demoData;
} 