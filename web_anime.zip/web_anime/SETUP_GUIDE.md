# 🔥 Panduan Setup Firebase untuk AnimeReview

Konfigurasi Firebase Anda sudah berhasil ditambahkan ke project! Sekarang tinggal beberapa langkah lagi untuk menyelesaikan setup.

## ✅ Status Setup
- [x] Project Firebase dibuat: `review-anime`
- [x] Konfigurasi Firebase sudah diupdate
- [x] Error fixes applied
- [ ] Authentication setup (WAJIB)
- [ ] Realtime Database setup (WAJIB)
- [ ] Database Rules setup (WAJIB)

## 📋 Langkah-langkah Setup

### 1. Setup Authentication

1. Buka [Firebase Console](https://console.firebase.google.com/)
2. Pilih project **review-anime**
3. Di sidebar kiri, klik **Authentication**
4. Klik tab **Sign-in method**
5. Klik **Email/Password**
6. **Enable** Email/Password
7. Klik **Save**

### 2. Setup Realtime Database

1. Masih di Firebase Console
2. Di sidebar kiri, klik **Realtime Database**
3. Klik **Create Database**
4. Pilih lokasi: **asia-southeast1 (Singapore)** ✅ (sudah benar)
5. Pilih **Start in test mode** (untuk development)
6. Klik **Done**

### 3. Setup Database Rules (WAJIB - Untuk mengatasi permission denied error)

**PENTING**: Anda HARUS setup database rules untuk mengatasi error permission denied.

#### Opsi 1: Test Mode (Mudah, untuk development)
1. Di Firebase Console > Realtime Database
2. Klik tab **Rules**
3. Ganti rules dengan:
```json
{
  "rules": {
    ".read": true,
    ".write": true
  }
}
```
4. Klik **Publish**

#### Opsi 2: Production Rules (Aman, untuk production)
Gunakan rules dari file `firebase-rules.json`:

```json
{
  "rules": {
    "users": {
      "$uid": {
        ".read": "$uid === auth.uid",
        ".write": "$uid === auth.uid"
      }
    },
    "reviews": {
      ".read": "auth != null",
      ".write": "auth != null",
      "$reviewId": {
        ".validate": "newData.hasChildren(['title', 'rating', 'review', 'authorId'])",
        "authorId": {
          ".validate": "newData.val() === auth.uid"
        },
        "comments": {
          "$commentId": {
            ".validate": "newData.hasChildren(['text', 'authorId'])",
            "authorId": {
              ".validate": "newData.val() === auth.uid"
            }
          }
        }
      }
    }
  }
}
```

## 🚀 Menjalankan Website

1. Buka file `index.html` di browser
2. Atau upload ke web server/hosting
3. Website siap digunakan!

## 🧪 Testing dengan Demo Data

Setelah setup selesai:

1. Buka website di browser
2. Register akun baru atau login
3. Buka Developer Console (F12)
4. Jalankan perintah berikut untuk menambah data demo:

```javascript
// Menambah data review demo
addDemoData();

// Menambah user demo
addDemoUsers();

// Test fungsi search
testSearch();
```

## 🔧 Konfigurasi Database URL

Database URL Anda sudah benar:
```
https://review-anime-default-rtdb.asia-southeast1.firebasedatabase.app/
```

## 📱 Fitur yang Tersedia

### ✅ Fitur Lengkap:
- **Welcome Page**: Halaman sambutan yang menarik
- **Authentication**: Register & Login dengan email/password
- **Dashboard**: Panel utama setelah login
- **Add Review**: Form untuk menambah review anime
- **Image Upload**: Upload gambar dengan konversi base64
- **Search**: Pencarian real-time berdasarkan judul, genre, review, atau komentar
- **Comments**: Sistem komentar real-time
- **Responsive Design**: Tampilan optimal di semua perangkat

### 🎨 Design Features:
- Modern gradient design
- Smooth animations
- Card-based layout
- Star rating system
- Real-time notifications
- Loading animations

## 🐛 Troubleshooting

### Jika Authentication tidak berfungsi:
1. Pastikan Email/Password sudah di-enable di Firebase Console
2. Cek apakah ada error di browser console
3. Pastikan domain sudah ditambahkan ke Authorized domains

### Jika Database tidak berfungsi:
1. Pastikan Realtime Database sudah dibuat
2. Cek Database Rules (gunakan test mode untuk development)
3. Pastikan URL database sudah benar

### Jika gambar tidak muncul:
1. Pastikan file gambar tidak terlalu besar (max 1MB)
2. Cek format gambar yang didukung (jpg, png, gif)
3. Pastikan konversi base64 berhasil

## 🎯 Cara Penggunaan

1. **Register**: Buat akun baru dengan email dan password
2. **Login**: Masuk dengan akun yang sudah dibuat
3. **Add Review**: Isi form di sidebar kanan untuk menambah review
4. **Search**: Gunakan search bar untuk mencari review
5. **Comment**: Klik di bagian komentar untuk menambah komentar
6. **Logout**: Klik logout untuk keluar

## 📊 Struktur Database

```
review-anime/
├── users/
│   └── [userId]/
│       ├── name: "User Name"
│       ├── email: "user@email.com"
│       └── createdAt: timestamp
└── reviews/
    └── [reviewId]/
        ├── title: "Anime Title"
        ├── genre: "Action, Drama"
        ├── rating: 9
        ├── review: "Review text"
        ├── image: "base64 string"
        ├── authorId: "userId"
        ├── authorName: "User Name"
        ├── createdAt: timestamp
        └── comments/
            └── [commentId]/
                ├── text: "Comment text"
                ├── authorId: "userId"
                ├── authorName: "User Name"
                └── createdAt: timestamp
```

## 🔒 Security Notes

- Untuk production, gunakan database rules yang lebih ketat
- Jangan expose API key di public repository
- Gunakan environment variables untuk sensitive data
- Regular backup database

---

**Website AnimeReview Anda sudah siap digunakan! 🎌**

Jika ada pertanyaan atau masalah, silakan check troubleshooting guide di atas. 