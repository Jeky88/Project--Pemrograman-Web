# 🚨 Quick Fix untuk Error AnimeReview

## Error yang Sudah Diperbaiki:
- ✅ Service Worker error (SW disabled)
- ✅ querySelector syntax error
- ✅ Better error handling untuk auth dan database

## Error yang Masih Perlu Setup:

### 1. 🔥 Authentication Error (400)
**Masalah**: Email/Password authentication belum diaktifkan di Firebase

**Solusi**:
1. Buka [Firebase Console](https://console.firebase.google.com/)
2. Pilih project **review-anime**
3. Klik **Authentication** di sidebar
4. Klik tab **Sign-in method**
5. Klik **Email/Password**
6. **Enable** kedua opsi (Email/Password dan Email link)
7. Klik **Save**

### 2. 🔥 Database Permission Denied
**Masalah**: Database rules tidak mengizinkan read/write

**Solusi Cepat (untuk testing)**:
1. Buka [Firebase Console](https://console.firebase.google.com/)
2. Pilih project **review-anime**
3. Klik **Realtime Database** di sidebar
4. Jika belum ada database, klik **Create Database**
5. Klik tab **Rules**
6. Ganti rules dengan:
```json
{
  "rules": {
    ".read": true,
    ".write": true
  }
}
```
7. Klik **Publish**

**⚠️ PERINGATAN**: Rules di atas tidak aman untuk production!

## 🧪 Testing Setelah Fix:

1. **Refresh halaman** website
2. **Register** akun baru dengan:
   - Email: test@example.com
   - Password: 123456 (minimal 6 karakter)
   - Nama: Test User
3. **Login** dengan akun yang baru dibuat
4. **Tambah review** anime untuk testing
5. **Test search** dan comment features

## 🔧 Jika Masih Ada Error:

### Browser Console Error:
1. Tekan **F12** untuk buka Developer Tools
2. Klik tab **Console**
3. Refresh halaman
4. Lihat error yang muncul

### Firebase Console Error:
1. Buka Firebase Console
2. Cek **Authentication** > **Users** (apakah user terdaftar?)
3. Cek **Realtime Database** > **Data** (apakah data tersimpan?)

## 📞 Common Issues:

### "auth/operation-not-allowed"
- Authentication belum diaktifkan
- Ikuti langkah Authentication Error di atas

### "PERMISSION_DENIED"
- Database rules terlalu ketat
- Ikuti langkah Database Permission Denied di atas

### "auth/weak-password"
- Password kurang dari 6 karakter
- Gunakan password minimal 6 karakter

### "auth/email-already-in-use"
- Email sudah digunakan
- Gunakan email lain atau login dengan email tersebut

## 🎯 Hasil yang Diharapkan:

Setelah setup berhasil:
- ✅ Register/Login berhasil tanpa error
- ✅ Bisa menambah review anime
- ✅ Search berfungsi
- ✅ Comment system bekerja
- ✅ Gambar bisa diupload

---

**Ikuti langkah-langkah di atas secara berurutan untuk mengatasi semua error!** 🚀 