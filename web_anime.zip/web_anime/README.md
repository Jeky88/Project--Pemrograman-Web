# AnimeReview - Platform Review Anime

Platform review anime modern dengan fitur lengkap seperti social media untuk berbagi dan berdiskusi tentang anime favorit Anda.

## 🌟 Fitur Utama

### ✅ Fitur yang Sudah Tersedia
- **Welcome Page** - Halaman sambutan dengan preview anime trending
- **Authentication System** - Register/Login dengan Firebase Auth
- **Dashboard Social Media** - Feed post seperti social media
- **Create Post** - Buat review anime dengan rating dan gambar (Base64)
- **Like & Comment System** - Interaksi dengan post lain
- **Search & Filter** - Cari anime berdasarkan judul, genre, atau user
- **Merge Rating** - Gabungkan rating untuk anime yang sama
- **Profile Page** - Halaman profil dengan statistik dan chart
- **Responsive Design** - Tampilan optimal di semua device
- **Real-time Updates** - Data ter-update secara real-time

### 🔄 Fitur dalam Pengembangan
- Advanced Search dengan filter multiple
- Follow/Unfollow user system
- Notification system
- Export review ke PDF
- Dark mode toggle

## 🚀 Cara Menjalankan

### 1. Setup Firebase
1. Buat project Firebase di [Firebase Console](https://console.firebase.google.com/)
2. Aktifkan Authentication dengan Email/Password
3. Buat Realtime Database dengan rules:
```json
{
  "rules": {
    ".read": true,
    ".write": "auth != null"
  }
}
```
4. Copy konfigurasi Firebase ke `js/firebase-config.js`

### 2. Jalankan Website
1. Clone atau download repository
2. Buka `welcome.html` di browser
3. Atau gunakan local server:
```bash
# Menggunakan Python
python -m http.server 8000

# Menggunakan Node.js
npx http-server

# Menggunakan PHP
php -S localhost:8000
```

### 3. Testing dengan Demo Data
- Demo data akan otomatis ter-load saat development di localhost
- Berisi sample anime, reviews, dan users untuk testing

## 📱 Struktur Halaman

```
├── welcome.html          # Halaman utama/landing page
├── dashboard.html        # Dashboard utama (social media feed)
├── profile.html          # Halaman profil user
├── index.html           # Redirect ke welcome.html
├── styles.css           # CSS utama
├── js/
│   ├── firebase-config.js    # Konfigurasi Firebase
│   ├── welcome.js           # JavaScript untuk welcome page
│   ├── dashboard.js         # JavaScript untuk dashboard
│   └── profile.js           # JavaScript untuk profile page
├── demo-data.js         # Data demo untuk testing
└── README.md           # Dokumentasi ini
```

## 🎯 Cara Menggunakan

### 1. Registrasi/Login
- Buka `welcome.html`
- Klik "Daftar" untuk registrasi atau "Masuk" untuk login
- Setelah berhasil, otomatis redirect ke dashboard

### 2. Membuat Review
- Di dashboard, klik "Post Review Baru" atau area create post
- Isi form:
  - **Judul Anime** (wajib)
  - **Genre** (opsional, pisahkan dengan koma)
  - **Rating** (1-10 dengan slider)
  - **Review** (wajib)
  - **Gambar** (opsional, akan dikonversi ke Base64)
  - **Allow Merge** (centang untuk merge rating dengan anime sama)
- Klik "Post Review"

### 3. Interaksi dengan Post
- **Like**: Klik tombol ❤️ untuk menyukai post
- **Comment**: Klik tombol 💬 untuk berkomentar
- **Share**: Klik tombol 📤 untuk copy link post
- **View Image**: Klik gambar untuk melihat dalam modal

### 4. Search & Filter
- **Search**: Ketik di search box untuk cari anime, user, atau genre
- **Filter**: Pilih filter (Terbaru, Terpopuler, Rating Tertinggi, dll)
- **Load More**: Klik "Load More Posts" untuk memuat lebih banyak

### 5. Profile Management
- Klik nama user di navbar → Profile
- Edit profile dengan klik "Edit Profile"
- Lihat statistik di tab "Statistics"
- Chart aktivitas menunjukkan post per hari

## 🔧 Fitur Teknis

### Upload Gambar Base64
```javascript
// Otomatis convert gambar ke Base64
const imageFile = document.getElementById('animeImage').files[0];
const imageBase64 = await convertToBase64(imageFile);
```

### Merge Rating System
```javascript
// Jika anime sudah ada dan allow merge = true
if (existingAnimeId && allowMerge) {
    const newAvgRating = ((existingRating * reviewCount) + newRating) / (reviewCount + 1);
    // Update existing post dengan rating baru
}
```

### Real-time Updates
```javascript
// Listen untuk perubahan data
database.ref('posts').on('value', (snapshot) => {
    // Update UI secara real-time
});
```

## 🎨 Kustomisasi

### Mengubah Tema
Edit variabel CSS di `styles.css`:
```css
:root {
    --primary-color: #007bff;
    --anime-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}
```

### Menambah Fitur
1. Tambahkan HTML di file yang sesuai
2. Buat function JavaScript di file `js/`
3. Integrasikan dengan Firebase database
4. Update CSS untuk styling

## 📊 Database Structure

```
Firebase Realtime Database:
├── posts/
│   ├── postId/
│   │   ├── title: "Anime Title"
│   │   ├── genre: "Action, Drama"
│   │   ├── rating: 8.5
│   │   ├── review: "Review content"
│   │   ├── image: "base64_string"
│   │   ├── authorId: "user_id"
│   │   ├── authorName: "User Name"
│   │   ├── createdAt: timestamp
│   │   ├── likes: { userId: { timestamp, userName } }
│   │   ├── comments: { commentId: { text, authorId, authorName, createdAt } }
│   │   ├── shares: number
│   │   └── mergedReviews: { reviewId: { review, rating, authorId, authorName, createdAt } }
└── users/
    ├── userId/
    │   ├── name: "User Name"
    │   ├── email: "user@email.com"
    │   ├── bio: "User bio"
    │   ├── postCount: number
    │   ├── likeCount: number
    │   ├── commentCount: number
    │   └── joinDate: date
```

## 🐛 Troubleshooting

### Error: Firebase not initialized
- Pastikan `js/firebase-config.js` sudah dikonfigurasi dengan benar
- Cek console browser untuk error detail

### Error: Permission denied
- Pastikan Firebase rules sudah diset dengan benar
- User harus login untuk write operations

### Gambar tidak muncul
- Pastikan ukuran gambar < 2MB
- Format yang didukung: JPG, PNG, GIF
- Gambar akan otomatis dikonversi ke Base64

### Performance Issues
- Gunakan pagination untuk post (sudah implemented)
- Compress gambar sebelum upload
- Limit jumlah data yang di-load

## 🤝 Kontribusi

1. Fork repository
2. Buat branch fitur (`git checkout -b feature/AmazingFeature`)
3. Commit perubahan (`git commit -m 'Add some AmazingFeature'`)
4. Push ke branch (`git push origin feature/AmazingFeature`)
5. Buat Pull Request

## 📄 License

Project ini menggunakan MIT License. Lihat file `LICENSE` untuk detail.

## 🙏 Acknowledgments

- [Firebase](https://firebase.google.com/) - Backend as a Service
- [Bootstrap 5](https://getbootstrap.com/) - CSS Framework
- [Font Awesome](https://fontawesome.com/) - Icons
- [Chart.js](https://www.chartjs.org/) - Charts untuk statistics

---

**Dibuat dengan ❤️ untuk komunitas anime Indonesia**

Jika ada bug atau saran, silakan buat issue di repository ini! 